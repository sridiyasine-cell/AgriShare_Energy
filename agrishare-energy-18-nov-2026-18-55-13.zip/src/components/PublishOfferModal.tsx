import React, { useState } from 'react';
import { X } from 'lucide-react';
import { ALGERIA_WILAYAS } from '../data/algeriaWilayas';
import { EnergyOffer, EquipmentItem } from '../types/agrishare';

interface PublishOfferModalProps {
  isOpen: boolean;
  defaultWilayaCode?: string;
  onClose: () => void;
  onPublishEquipment: (item: EquipmentItem) => void;
  onPublishEnergy: (offer: EnergyOffer) => void;
}

export const PublishOfferModal: React.FC<PublishOfferModalProps> = ({
  isOpen,
  defaultWilayaCode = '09',
  onClose,
  onPublishEquipment,
  onPublishEnergy,
}) => {
  const [offerKind, setOfferKind] = useState<'equipment' | 'energy'>('equipment');

  // Equipment fields
  const [eqName, setEqName] = useState('');
  const [eqCategory, setEqCategory] = useState<'tractor' | 'harvester' | 'irrigation' | 'seeder'>('tractor');
  const [eqOwner, setEqOwner] = useState('');
  const [eqWilayaCode, setEqWilayaCode] = useState(
    defaultWilayaCode === 'all' ? '09' : defaultWilayaCode
  );
  const [eqMunicipality, setEqMunicipality] = useState('');
  const [eqHourPrice, setEqHourPrice] = useState(3200);
  const [eqHectarePrice, setEqHectarePrice] = useState(5000);
  const [eqPower, setEqPower] = useState('120 حصان');

  // Energy fields
  const [enTitle, setEnTitle] = useState('');
  const [enProvider, setEnProvider] = useState('');
  const [enWilayaCode, setEnWilayaCode] = useState(
    defaultWilayaCode === 'all' ? '39' : defaultWilayaCode
  );
  const [enMunicipality, setEnMunicipality] = useState('');
  const [enMode, setEnMode] = useState<'battery_pickup' | 'battery_delivery' | 'direct_grid'>('battery_pickup');
  const [enSurplus, setEnSurplus] = useState(75);
  const [enBatteries, setEnBatteries] = useState(4);
  const [enPriceKwh, setEnPriceKwh] = useState(12);

  if (!isOpen) return null;

  const categoryLabels: Record<typeof eqCategory, string> = {
    tractor: 'جرارات',
    harvester: 'حصادات',
    irrigation: 'مضخات ري',
    seeder: 'بذارات',
  };

  const categoryImages: Record<typeof eqCategory, string> = {
    tractor: '/src/assets/images/equip_tractor_heavy_1795023439476.jpg',
    harvester: '/src/assets/images/equip_combine_harvester_1795023439350.jpg',
    irrigation: '/src/assets/images/equip_solar_pump_1795023439945.jpg',
    seeder: '/src/assets/images/equip_tractor_heavy_1795023439476.jpg',
  };

  const modeLabels: Record<typeof enMode, string> = {
    battery_pickup: 'تعبئة واستلام بطارية',
    battery_delivery: 'توصيل للحقل المعزول',
    direct_grid: 'ربط مباشر بين الحقول',
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (offerKind === 'equipment') {
      if (!eqName.trim() || !eqOwner.trim()) return;
      const wilaya =
        ALGERIA_WILAYAS.find((w) => w.code === eqWilayaCode) ?? ALGERIA_WILAYAS[8];
      const regionLabel = eqMunicipality.trim()
        ? `${wilaya.name} (${wilaya.code}) · ${eqMunicipality.trim()}`
        : `${wilaya.name} (${wilaya.code}) · ${wilaya.zone}`;

      onPublishEquipment({
        id: `eq-${Date.now()}`,
        name: eqName.trim(),
        category: eqCategory,
        categoryLabel: categoryLabels[eqCategory],
        ownerName: eqOwner.trim(),
        wilayaCode: wilaya.code,
        wilayaName: wilaya.name,
        ownerRegion: regionLabel,
        distanceKm: 2.5,
        pricePerHour: eqHourPrice,
        pricePerHectare: eqHectarePrice,
        horsepower: eqPower.trim() || '110 حصان',
        rating: 5.0,
        reviewsCount: 1,
        operatingHours: 320,
        lastInspectionDate: '2026-11-18',
        technicalStatus: 'جاهز للعمل',
        nearestRouteId: 'rt-1',
        nearestRouteName: `مسار ولاية ${wilaya.name} الموحد`,
        imageUrl: categoryImages[eqCategory],
        description: `معدة مسجلة حديثاً للمشاركة المحلية في ${regionLabel} مع فحص فني معتمد.`,
        fuelEfficiencyNote: 'مؤهلة للدمج في الجدولة الجغرافية لتقليص استهلاك المازوت.',
      });
    } else {
      if (!enTitle.trim() || !enProvider.trim()) return;
      const wilaya =
        ALGERIA_WILAYAS.find((w) => w.code === enWilayaCode) ?? ALGERIA_WILAYAS[38];
      const regionLabel = enMunicipality.trim()
        ? `${wilaya.name} (${wilaya.code}) · ${enMunicipality.trim()}`
        : `${wilaya.name} (${wilaya.code}) · ${wilaya.zone}`;

      onPublishEnergy({
        id: `en-${Date.now()}`,
        title: enTitle.trim(),
        providerName: enProvider.trim(),
        wilayaCode: wilaya.code,
        wilayaName: wilaya.name,
        region: regionLabel,
        distanceKm: 2.2,
        deliveryMode: enMode,
        deliveryModeLabel: modeLabels[enMode],
        surplusKwh: enSurplus,
        availableBatteries: enBatteries,
        batteryUnitCapacityKwh: 5,
        pricePerKwh: enPriceKwh,
        batteryPackPrice: Math.round(enPriceKwh * 15 + 40),
        batteryHealthPct: 98,
        chargeCycles: 45,
        rating: 5.0,
        reviewsCount: 1,
        solarPeakWindow: '09:30 ص – 04:00 م',
        imageUrl: '/src/assets/images/energy_solar_battery_hub_1795023440123.jpg',
        description: `فائض طاقة شمسية متاح للتبادل أو تعبئة البطاريات لخدمة المستثمرات القريبة في ${regionLabel}.`,
      });
    }
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#0F1F16]/50 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="publish-modal-title"
    >
      <div className="bg-white border border-[#E4E8E1] rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-5">
        <div className="flex items-center justify-between border-b border-[#EFF2ED] pb-4">
          <h3 id="publish-modal-title" className="text-lg font-bold text-[#0F1F16]">
            إضافة عرض جديد في الجزائر (58 ولاية)
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="p-2 text-[#4A5D52] hover:text-[#0F1F16] rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#F4F7F3] rounded-lg">
          <button
            type="button"
            onClick={() => setOfferKind('equipment')}
            className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
              offerKind === 'equipment'
                ? 'bg-white text-[#15803D] shadow-xs font-semibold'
                : 'text-[#4A5D52]'
            }`}
          >
            تسجيل معدة فلاحية
          </button>
          <button
            type="button"
            onClick={() => setOfferKind('energy')}
            className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
              offerKind === 'energy'
                ? 'bg-white text-[#B45309] shadow-xs font-semibold'
                : 'text-[#4A5D52]'
            }`}
          >
            عرض فائض طاقة / بطاريات
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {offerKind === 'equipment' ? (
            <>
              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  اسم المعدة وموديلها
                </label>
                <input
                  type="text"
                  required
                  value={eqName}
                  onChange={(e) => setEqName(e.target.value)}
                  placeholder="مثال: جرار New Holland T6 140"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    الفئة
                  </label>
                  <select
                    value={eqCategory}
                    onChange={(e) =>
                      setEqCategory(e.target.value as typeof eqCategory)
                    }
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  >
                    <option value="tractor">جرارات</option>
                    <option value="harvester">حصادات</option>
                    <option value="irrigation">مضخات ري</option>
                    <option value="seeder">بذارات</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    القدرة الحصانية
                  </label>
                  <input
                    type="text"
                    value={eqPower}
                    onChange={(e) => setEqPower(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    الولاية (58 ولاية)
                  </label>
                  <select
                    value={eqWilayaCode}
                    onChange={(e) => setEqWilayaCode(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  >
                    {ALGERIA_WILAYAS.map((w) => (
                      <option key={w.code} value={w.code}>
                        {w.code} — {w.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    البلدية / الدائرة
                  </label>
                  <input
                    type="text"
                    value={eqMunicipality}
                    onChange={(e) => setEqMunicipality(e.target.value)}
                    placeholder="مثال: بوفاريك"
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  اسم المالك أو التعاونية
                </label>
                <input
                  type="text"
                  required
                  value={eqOwner}
                  onChange={(e) => setEqOwner(e.target.value)}
                  placeholder="مثال: محمد العربي"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    السعر بالساعة (د.ج)
                  </label>
                  <input
                    type="number"
                    min={500}
                    step={100}
                    value={eqHourPrice}
                    onChange={(e) => setEqHourPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    السعر بالهكتار (د.ج)
                  </label>
                  <input
                    type="number"
                    min={1000}
                    step={100}
                    value={eqHectarePrice}
                    onChange={(e) => setEqHectarePrice(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  عنوان محطة الطاقة أو عرض الفائض
                </label>
                <input
                  type="text"
                  required
                  value={enTitle}
                  onChange={(e) => setEnTitle(e.target.value)}
                  placeholder="مثال: منظومة شمسية 25 كيلوواط — مستثمرة النخيل"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    الولاية (58 ولاية)
                  </label>
                  <select
                    value={enWilayaCode}
                    onChange={(e) => setEnWilayaCode(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                  >
                    {ALGERIA_WILAYAS.map((w) => (
                      <option key={w.code} value={w.code}>
                        {w.code} — {w.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    البلدية / المحيط الفلاحي
                  </label>
                  <input
                    type="text"
                    value={enMunicipality}
                    onChange={(e) => setEnMunicipality(e.target.value)}
                    placeholder="مثال: قمار"
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  اسم المزود
                </label>
                <input
                  type="text"
                  required
                  value={enProvider}
                  onChange={(e) => setEnProvider(e.target.value)}
                  placeholder="مثال: مزرعة النور الفلاحية"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  طريقة التزويد والتوزيع
                </label>
                <select
                  value={enMode}
                  onChange={(e) => setEnMode(e.target.value as typeof enMode)}
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                >
                  <option value="battery_pickup">تعبئة واستلام بطارية</option>
                  <option value="battery_delivery">توصيل للحقل المعزول</option>
                  <option value="direct_grid">ربط مباشر بين الحقول</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    الفائض (kWh)
                  </label>
                  <input
                    type="number"
                    min={10}
                    value={enSurplus}
                    onChange={(e) => setEnSurplus(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    بطاريات جاهزة
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={enBatteries}
                    onChange={(e) => setEnBatteries(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                    سعر kWh (د.ج)
                  </label>
                  <input
                    type="number"
                    step={1}
                    min={5}
                    value={enPriceKwh}
                    onChange={(e) => setEnPriceKwh(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                  />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            className="w-full py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors min-h-[42px]"
          >
            نشر العرض بالدينار الجزائري فوراً
          </button>
        </form>
      </div>
    </div>
  );
};
