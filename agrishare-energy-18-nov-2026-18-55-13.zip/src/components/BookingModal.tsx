import React, { useState } from 'react';
import { CheckCircle2, Shield, X } from 'lucide-react';
import { ALGERIA_WILAYAS, formatDzd } from '../data/algeriaWilayas';
import {
  BookingRecord,
  EnergyOffer,
  EquipmentItem,
  MaintenanceProvider,
  PricingUnit,
} from '../types/agrishare';

export type BookingTarget =
  | { type: 'equipment'; item: EquipmentItem; preferredUnit: PricingUnit }
  | { type: 'energy'; offer: EnergyOffer }
  | { type: 'maintenance'; provider: MaintenanceProvider };

interface BookingModalProps {
  target: BookingTarget | null;
  onClose: () => void;
  onConfirmBooking: (record: Omit<BookingRecord, 'id' | 'createdAt'>) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  target,
  onClose,
  onConfirmBooking,
}) => {
  const [unit, setUnit] = useState<PricingUnit>(
    target?.type === 'equipment' ? target.preferredUnit : 'hour'
  );
  const [quantity, setQuantity] = useState(3);
  const [energyMode, setEnergyMode] = useState<'battery' | 'kwh'>('battery');
  const [batteryCount, setBatteryCount] = useState(2);
  const [kwhAmount, setKwhAmount] = useState(25);
  const [joinSmartRoute, setJoinSmartRoute] = useState(true);
  const [withInsurance, setWithInsurance] = useState(true);
  const [selectedWilaya, setSelectedWilaya] = useState(
    target?.type === 'equipment'
      ? target.item.wilayaCode
      : target?.type === 'energy'
      ? target.offer.wilayaCode
      : target?.type === 'maintenance'
      ? target.provider.wilayaCode
      : '09'
  );
  const [farmerLocation, setFarmerLocation] = useState('المستثمرة الفلاحية — بلدية الولاية');
  const [confirmedCode, setConfirmedCode] = useState<string | null>(null);

  if (!target) return null;

  let itemTitle = '';
  let providerName = '';
  let baseAmount = 0;
  let routeDiscount = 0;
  let quantityLabel = '';
  let deliveryNote = '';

  if (target.type === 'equipment') {
    itemTitle = target.item.name;
    providerName = target.item.ownerName;
    const rate =
      unit === 'hour' ? target.item.pricePerHour : target.item.pricePerHectare;
    const transportBase = 1200;
    routeDiscount = joinSmartRoute ? Math.round(transportBase * 0.4) : 0;
    baseAmount = rate * quantity + (transportBase - routeDiscount);
    quantityLabel = `${quantity} ${unit === 'hour' ? 'ساعة' : 'هكتار'}`;
    deliveryNote = joinSmartRoute
      ? `مدمج مع ${target.item.nearestRouteName} (توفير نقل ${formatDzd(routeDiscount)})`
      : 'تنقل مباشر منفرد للحقل';
  } else if (target.type === 'energy') {
    itemTitle = target.offer.title;
    providerName = target.offer.providerName;
    if (energyMode === 'battery') {
      baseAmount = target.offer.batteryPackPrice * batteryCount;
      quantityLabel = `${batteryCount} بطارية (${
        batteryCount * target.offer.batteryUnitCapacityKwh
      } kWh)`;
    } else {
      baseAmount = target.offer.pricePerKwh * kwhAmount;
      quantityLabel = `${kwhAmount} kWh طاقة شمسية`;
    }
    deliveryNote = target.offer.deliveryModeLabel;
  } else {
    itemTitle = `خدمة فنية: ${target.provider.specialty}`;
    providerName = target.provider.name;
    baseAmount = target.provider.baseFee;
    quantityLabel = `زيارة ميدانية (${target.provider.responseTime})`;
    deliveryNote = target.provider.region;
  }

  const microInsuranceFee = withInsurance ? 450 : 0;
  const platformCommission = Math.round(baseAmount * 0.06);
  const totalPaid = Math.round(
    baseAmount + microInsuranceFee + platformCommission
  );

  const wilayaObj = ALGERIA_WILAYAS.find((w) => w.code === selectedWilaya);
  const wilayaDisplay = wilayaObj ? `${wilayaObj.name} (${wilayaObj.code})` : selectedWilaya;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = `DZ-${Math.floor(1000 + Math.random() * 9000)}`;
    onConfirmBooking({
      kind: target.type,
      itemTitle,
      providerName,
      quantityLabel,
      baseAmount: Math.round(baseAmount),
      routeDiscount,
      microInsuranceFee,
      platformCommission,
      totalPaid,
      deliveryNote: `${deliveryNote} · ولاية ${wilayaDisplay} · ${farmerLocation}`,
    });
    setConfirmedCode(code);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#0F1F16]/50 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div className="bg-white border border-[#E4E8E1] rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-5">
        <div className="flex items-start justify-between gap-4 border-b border-[#EFF2ED] pb-4">
          <div>
            <div className="text-xs font-medium text-[#15803D]">
              {target.type === 'equipment'
                ? 'حجز معدة فلاحية والسجل الفني'
                : target.type === 'energy'
                ? 'شراء طاقة شمسية / تعبئة بطاريات'
                : 'طلب صيانة وتركيب معتمد'}
            </div>
            <h3
              id="booking-modal-title"
              className="text-lg font-bold text-[#0F1F16] mt-1"
            >
              {itemTitle}
            </h3>
            <div className="text-xs text-[#4A5D52] mt-0.5">{providerName}</div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق النافذة"
            className="p-2 text-[#4A5D52] hover:text-[#0F1F16] hover:bg-[#F7F9F6] rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmedCode ? (
          <div className="py-6 text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-[#15803D] mx-auto" />
            <div className="space-y-1">
              <h4 className="text-lg font-bold text-[#0F1F16]">
                تم تأكيد الطلب وإدراجه في السجل بنجاح
              </h4>
              <p className="text-sm text-[#4A5D52]">
                رقم المرجع الموثق:{' '}
                <span className="font-mono font-bold text-[#0F1F16]">
                  {confirmedCode}
                </span>
              </p>
              <p className="text-xs text-[#617569]">
                الإجمالي المحتسب: {formatDzd(totalPaid)} (شامل عمولة المنصة 6%
                {withInsurance ? ' والتأمين المصغر' : ''})
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors"
            >
              العودة للمنصة
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {target.type === 'equipment' && (
              <>
                <div className="bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg p-3 text-xs text-[#4A5D52] space-y-1">
                  <div>
                    السجل الفني: {target.item.operatingHours} ساعة تشغيل · آخر فحص{' '}
                    <span className="font-mono">{target.item.lastInspectionDate}</span>
                  </div>
                  <div className="text-[#15803D] font-medium">
                    {target.item.fuelEfficiencyNote}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                      نظام الحجز
                    </label>
                    <select
                      value={unit}
                      onChange={(e) => setUnit(e.target.value as PricingUnit)}
                      className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                    >
                      <option value="hour">
                        بالساعة ({formatDzd(target.item.pricePerHour)})
                      </option>
                      <option value="hectare">
                        بالهكتار ({formatDzd(target.item.pricePerHectare)})
                      </option>
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="eq-qty"
                      className="block text-xs font-medium text-[#4A5D52] mb-1"
                    >
                      الكمية ({unit === 'hour' ? 'ساعات' : 'هكتارات'})
                    </label>
                    <input
                      id="eq-qty"
                      type="number"
                      min={1}
                      max={40}
                      value={quantity}
                      onChange={(e) =>
                        setQuantity(Math.max(1, Number(e.target.value)))
                      }
                      className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                    />
                  </div>
                </div>

                <label className="flex items-start gap-2.5 text-xs text-[#0F1F16] cursor-pointer p-3 rounded-lg border border-[#E4E8E1] bg-[#F9FBF8]">
                  <input
                    type="checkbox"
                    checked={joinSmartRoute}
                    onChange={(e) => setJoinSmartRoute(e.target.checked)}
                    className="mt-0.5 rounded border-[#C5D1C3] text-[#15803D]"
                  />
                  <span>
                    <strong className="block">
                      الدمج في {target.item.nearestRouteName}
                    </strong>
                    <span className="text-[#4A5D52]">
                      يخفض تكلفة نقل المعدة 40% ({formatDzd(480)} توفير) ويقلل استهلاك المازوت.
                    </span>
                  </span>
                </label>
              </>
            )}

            {target.type === 'energy' && (
              <>
                <div className="bg-[#FAF9F6] border border-[#E4E8E1] rounded-lg p-3 text-xs text-[#4A5D52] space-y-1">
                  <div>
                    صحة البطاريات: {target.offer.batteryHealthPct}% · دورات الشحن:{' '}
                    <span className="font-mono">{target.offer.chargeCycles}</span>
                  </div>
                  <div>
                    ذروة الفائض الشمسي: {target.offer.solarPeakWindow} ·{' '}
                    {target.offer.deliveryModeLabel}
                  </div>
                </div>

                <div className="flex items-center gap-1 p-1 bg-[#F4F7F3] rounded-lg">
                  <button
                    type="button"
                    onClick={() => setEnergyMode('battery')}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                      energyMode === 'battery'
                        ? 'bg-white text-[#B45309] shadow-xs font-semibold'
                        : 'text-[#4A5D52]'
                    }`}
                  >
                    حجز وتعبئة بطاريات
                  </button>
                  <button
                    type="button"
                    onClick={() => setEnergyMode('kwh')}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                      energyMode === 'kwh'
                        ? 'bg-white text-[#B45309] shadow-xs font-semibold'
                        : 'text-[#4A5D52]'
                    }`}
                  >
                    شراء بالكيلوواط (kWh)
                  </button>
                </div>

                {energyMode === 'battery' ? (
                  <div>
                    <label
                      htmlFor="battery-qty"
                      className="block text-xs font-medium text-[#4A5D52] mb-1"
                    >
                      عدد البطاريات المعبأة ({target.offer.batteryUnitCapacityKwh} kWh
                      للبطارية · {formatDzd(target.offer.batteryPackPrice)})
                    </label>
                    <input
                      id="battery-qty"
                      type="number"
                      min={1}
                      max={Math.max(1, target.offer.availableBatteries)}
                      value={batteryCount}
                      onChange={(e) =>
                        setBatteryCount(Math.max(1, Number(e.target.value)))
                      }
                      className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                    />
                  </div>
                ) : (
                  <div>
                    <label
                      htmlFor="kwh-qty"
                      className="block text-xs font-medium text-[#4A5D52] mb-1"
                    >
                      كمية الطاقة المطلوبة (kWh · {formatDzd(target.offer.pricePerKwh)} / kWh)
                    </label>
                    <input
                      id="kwh-qty"
                      type="number"
                      min={5}
                      max={target.offer.surplusKwh}
                      value={kwhAmount}
                      onChange={(e) =>
                        setKwhAmount(Math.max(5, Number(e.target.value)))
                      }
                      className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#D97706]"
                    />
                  </div>
                )}
              </>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="booking-wilaya"
                  className="block text-xs font-medium text-[#4A5D52] mb-1"
                >
                  الولاية (58 ولاية)
                </label>
                <select
                  id="booking-wilaya"
                  value={selectedWilaya}
                  onChange={(e) => setSelectedWilaya(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                >
                  {ALGERIA_WILAYAS.map((w) => (
                    <option key={w.code} value={w.code}>
                      {w.code} — {w.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="farmer-loc"
                  className="block text-xs font-medium text-[#4A5D52] mb-1"
                >
                  البلدية / موقع المستثمرة
                </label>
                <input
                  id="farmer-loc"
                  type="text"
                  required
                  value={farmerLocation}
                  onChange={(e) => setFarmerLocation(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                />
              </div>
            </div>

            <label className="flex items-start gap-2.5 text-xs text-[#0F1F16] cursor-pointer p-3 rounded-lg border border-[#E4E8E1]">
              <input
                type="checkbox"
                checked={withInsurance}
                onChange={(e) => setWithInsurance(e.target.checked)}
                className="mt-0.5 rounded border-[#C5D1C3] text-[#15803D]"
              />
              <span className="flex-1">
                <strong className="inline-flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-[#15803D]" aria-hidden="true" />
                  تفعيل التأمين المصغر (+{formatDzd(450)})
                </strong>
                <span className="block text-[#4A5D52] mt-0.5">
                  حماية المعدة أو البطاريات من الأعطال الطارئة أثناء النقل والتشغيل الميداني.
                </span>
              </span>
            </label>

            {/* Transparent Financial Summary */}
            <div className="border-t border-[#EFF2ED] pt-3 space-y-1.5 text-xs">
              <div className="flex justify-between text-[#4A5D52]">
                <span>قيمة الخدمة ({quantityLabel})</span>
                <span className="font-mono tabular-nums">
                  {formatDzd(baseAmount)}
                </span>
              </div>
              <div className="flex justify-between text-[#4A5D52]">
                <span>عمولة الوساطة الرقمية (6%)</span>
                <span className="font-mono tabular-nums">
                  {formatDzd(platformCommission)}
                </span>
              </div>
              <div className="flex justify-between text-[#4A5D52]">
                <span>التأمين المصغر</span>
                <span className="font-mono tabular-nums">
                  {formatDzd(microInsuranceFee)}
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-[#0F1F16] pt-2 border-t border-[#EFF2ED]">
                <span>الإجمالي المستحق بالدينار</span>
                <span className="font-mono tabular-nums text-[#15803D]">
                  {formatDzd(totalPaid)}
                </span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors min-h-[42px]"
            >
              تأكيد الحجز وإصدار السجل
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
