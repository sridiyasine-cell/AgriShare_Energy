import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { HERO_IMAGE_URL } from '../data/seedData';
import { PlatformView } from '../types/agrishare';
import { ResilientImage } from './ResilientImage';

interface HeroOverviewProps {
  equipmentCount: number;
  totalSurplusKwh: number;
  totalDieselSavedLiters: number;
  bookingsCount: number;
  onNavigateView: (view: PlatformView) => void;
}

export const HeroOverview: React.FC<HeroOverviewProps> = ({
  equipmentCount,
  totalSurplusKwh,
  totalDieselSavedLiters,
  bookingsCount,
  onNavigateView,
}) => {
  const scrollToWorkspace = (view: PlatformView) => {
    onNavigateView(view);
    const el = document.getElementById('workspace-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-6">
      {/* 2-Column Balanced Split Hero */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-between bg-white border border-[#E4E8E1] rounded-xl p-6 sm:p-8">
          <div>
            <p className="text-xs font-medium text-[#4A5D52] mb-3">
              متوفرة عبر 58 ولاية جزائرية · التعامل بالدينار الجزائري (د.ج) · الطاقة الشمسية الريفية
            </p>
            <h1 className="text-[clamp(1.85rem,3.3vw,2.75rem)] leading-[1.22] font-bold text-[#0F1F16] [text-wrap:balance] mb-4">
              تشارك المعدات الفلاحية وتبادل فائض الطاقة الشمسية عبر كل ولايات الجزائر
            </h1>
            <p className="text-base leading-relaxed text-[#4A5D52] max-w-2xl mb-6">
              تربط منصة AgriShare Energy الفلاحين الصغار في الشمال والهضاب العليا والجنوب بأصحاب الجرارات والحصادات المركونة، وتحوّل فائض الألواح الشمسية والبطاريات المعبأة إلى طاقة نظيفة تصل للمستثمرات المعزولة بالدينار الجزائري دون مولدات المازوت.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => scrollToWorkspace('equipment')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[42px]"
            >
              <span>استكشف سوق المعدات</span>
              <ArrowLeft className="w-4 h-4 shrink-0" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => scrollToWorkspace('energy')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#F7F9F6] hover:bg-[#ECF3ED] text-[#0F1F16] border border-[#D7E0D5] text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[42px]"
            >
              <span>سوق الطاقة والبطاريات</span>
            </button>
            <button
              type="button"
              onClick={() => scrollToWorkspace('requests')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-[#15803D] hover:text-[#166534] hover:underline text-sm font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[42px]"
            >
              <span>تسجيل وطلب احتياج</span>
            </button>
          </div>
        </div>

        <div className="lg:col-span-6 relative rounded-xl overflow-hidden border border-[#E4E8E1] min-h-[260px] lg:min-h-[360px]">
          <ResilientImage
            src={HERO_IMAGE_URL}
            alt="جرار زراعي يعمل في حقل أخضر بجانب ألواح الطاقة الشمسية الريفية"
            className="w-full h-full lg:h-full object-cover"
            fallbackType="equipment"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"
          />
          <div className="absolute bottom-0 inset-x-0 p-5 sm:p-6 text-white">
            <p className="text-xs text-white/80 mb-1">
              من متيجة والهضاب العليا إلى بسكرة والوادي وأدرار · 58 ولاية
            </p>
            <p className="text-sm sm:text-base font-medium leading-snug">
              الآلات الفلاحية تعمل بأقصى كفاءة في المستثمرات المتجاورة، وفائض شمس الظهيرة يشغّل مضخات السقي في المناطق المعزولة.
            </p>
          </div>
        </div>
      </div>

      {/* Full-Width 4-Column Regional KPI Strip */}
      <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 bg-white border border-[#E4E8E1] rounded-xl divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-[#E4E8E1]">
        <div className="p-4 sm:p-5">
          <div className="text-xs text-[#4A5D52] mb-1">التغطية الوطنية والمعدات</div>
          <div className="text-2xl font-bold text-[#0F1F16] font-mono tabular-nums">
            58 ولاية · {equipmentCount} آلات
          </div>
          <div className="text-xs text-[#617569] mt-1">كراء مرن بالساعة أو الهكتار بالدينار</div>
        </div>

        <div className="p-4 sm:p-5">
          <div className="text-xs text-[#4A5D52] mb-1">فائض الطاقة الشمسية اليومي</div>
          <div className="text-2xl font-bold text-[#B45309] font-mono tabular-nums">
            {totalSurplusKwh} kWh
          </div>
          <div className="text-xs text-[#617569] mt-1">ربط مباشر أو تعبئة بطاريات LiFePO4</div>
        </div>

        <div className="p-4 sm:p-5">
          <div className="text-xs text-[#4A5D52] mb-1">توفير المازوت عبر الجدولة</div>
          <div className="text-2xl font-bold text-[#15803D] font-mono tabular-nums">
            {totalDieselSavedLiters} لتر
          </div>
          <div className="text-xs text-[#617569] mt-1">تقليص مسارات التنقل الفارغة 40%</div>
        </div>

        <div className="p-4 sm:p-5">
          <div className="text-xs text-[#4A5D52] mb-1">حجوزات وتبادلات موثقة</div>
          <div className="text-2xl font-bold text-[#0F1F16] font-mono tabular-nums">
            {bookingsCount} معاملة
          </div>
          <div className="text-xs text-[#617569] mt-1">مغطاة بسجل فني وتأمين مصغر</div>
        </div>
      </div>
    </section>
  );
};
