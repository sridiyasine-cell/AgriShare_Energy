import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  ClipboardList,
  Phone,
  Search,
  UserCheck,
  UserPlus,
} from 'lucide-react';
import { ALGERIA_WILAYAS, formatDzd } from '../data/algeriaWilayas';
import {
  FarmerProfile,
  NeedCategory,
  NeedRequest,
} from '../types/agrishare';

interface FarmerRequestsViewProps {
  profile: FarmerProfile | null;
  requests: NeedRequest[];
  selectedWilaya: string;
  onSelectWilaya: (wilayaCode: string) => void;
  onRegisterProfile: (profile: FarmerProfile) => void;
  onResetProfile: () => void;
  onSubmitRequest: (
    req: Omit<NeedRequest, 'id' | 'status' | 'createdAt'>
  ) => void;
  onFulfillRequest: (requestId: string, providerName: string) => void;
}

const NEED_CATEGORIES: { id: NeedCategory; label: string }[] = [
  { id: 'equipment_rental', label: 'كراء معدة فلاحية (جرار / حصادة / بذارة)' },
  { id: 'energy_battery', label: 'شراء طاقة شمسية أو تعبئة بطاريات' },
  { id: 'solar_irrigation', label: 'مضخة ري شمسية متنقلة' },
  { id: 'maintenance_install', label: 'صيانة أو تركيب منظومة شمسية' },
];

export const FarmerRequestsView: React.FC<FarmerRequestsViewProps> = ({
  profile,
  requests,
  selectedWilaya,
  onSelectWilaya,
  onRegisterProfile,
  onResetProfile,
  onSubmitRequest,
  onFulfillRequest,
}) => {
  // Registration form state
  const [fullName, setFullName] = useState(profile?.fullName ?? '');
  const [roleType, setRoleType] = useState<FarmerProfile['roleType']>(
    profile?.roleType ?? 'مزارع صغير'
  );
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [regWilayaCode, setRegWilayaCode] = useState(
    profile?.wilayaCode ?? (selectedWilaya === 'all' ? '09' : selectedWilaya)
  );
  const [municipality, setMunicipality] = useState(profile?.municipality ?? '');
  const [gridStatus, setGridStatus] = useState<FarmerProfile['gridStatus']>(
    profile?.gridStatus ?? 'معزول / خارج الشبكة'
  );
  const [farmAreaHectares, setFarmAreaHectares] = useState(
    profile?.farmAreaHectares ?? '3'
  );
  const [regError, setRegError] = useState<string | null>(null);

  // Need request form state
  const [needCategory, setNeedCategory] =
    useState<NeedCategory>('equipment_rental');
  const [needTitle, setNeedTitle] = useState('');
  const [quantityNeeded, setQuantityNeeded] = useState('4 ساعات / 2 بطارية');
  const [neededDate, setNeededDate] = useState('2026-11-22');
  const [maxBudgetDzd, setMaxBudgetDzd] = useState(8500);
  const [notes, setNotes] = useState('');
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [guestWilaya, setGuestWilaya] = useState(
    selectedWilaya === 'all' ? '09' : selectedWilaya
  );
  const [guestMunicipality, setGuestMunicipality] = useState('');
  const [reqSubmittedNotice, setReqSubmittedNotice] = useState<string | null>(
    null
  );

  // Board filter state
  const [boardCategoryFilter, setBoardCategoryFilter] = useState<
    'all' | NeedCategory
  >('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [matchingRequestId, setMatchingRequestId] = useState<string | null>(
    null
  );
  const [responderName, setResponderName] = useState('');

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedPhone = phone.replace(/\s+/g, '');
    if (cleanedPhone.length < 9) {
      setRegError('يرجى إدخال رقم هاتف جزائري صحيح (9 أو 10 أرقام).');
      return;
    }
    setRegError(null);
    const wilaya =
      ALGERIA_WILAYAS.find((w) => w.code === regWilayaCode) ?? ALGERIA_WILAYAS[8];

    onRegisterProfile({
      memberCode: `DZ-MBR-${Math.floor(1000 + Math.random() * 9000)}`,
      fullName: fullName.trim(),
      roleType,
      phone: phone.trim(),
      wilayaCode: wilaya.code,
      wilayaName: wilaya.name,
      municipality: municipality.trim() || 'المركز',
      gridStatus,
      farmAreaHectares: farmAreaHectares.trim() || '2',
      registeredAt: '2026-11-18',
    });
  };

  const handleNeedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const activeName = profile ? profile.fullName : guestName.trim();
    const activePhone = profile ? profile.phone : guestPhone.trim();
    const activeWilayaCode = profile ? profile.wilayaCode : guestWilaya;
    const activeMunicipality = profile
      ? profile.municipality
      : guestMunicipality.trim() || 'البلدية';

    if (!activeName || !activePhone || !needTitle.trim()) return;

    const wilaya =
      ALGERIA_WILAYAS.find((w) => w.code === activeWilayaCode) ??
      ALGERIA_WILAYAS[8];

    const categoryShortLabels: Record<NeedCategory, string> = {
      equipment_rental: 'معدات فلاحية',
      energy_battery: 'طاقة وبطاريات',
      solar_irrigation: 'ري شمسي',
      maintenance_install: 'صيانة وتركيب',
    };

    onSubmitRequest({
      requesterName: activeName,
      requesterRole: profile ? profile.roleType : 'مواطن / مزارع',
      requesterPhone: activePhone,
      wilayaCode: wilaya.code,
      wilayaName: wilaya.name,
      municipality: activeMunicipality,
      isOffGrid: profile
        ? profile.gridStatus === 'معزول / خارج الشبكة'
        : false,
      category: needCategory,
      categoryLabel: categoryShortLabels[needCategory],
      title: needTitle.trim(),
      quantityNeeded: quantityNeeded.trim(),
      neededDate,
      maxBudgetDzd,
      notes: notes.trim() || 'يرجى التواصل لتنسيق الموعد والمسار الأقرب.',
    });

    setNeedTitle('');
    setNotes('');
    setReqSubmittedNotice(
      `تم نشر طلبك في ولاية ${wilaya.name} (${wilaya.code}) بنجاح وسيظهر لأصحاب المعدات والطاقة القريبين.`
    );
    setTimeout(() => setReqSubmittedNotice(null), 5000);
  };

  const filteredRequests = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return requests.filter((req) => {
      const matchesWilaya =
        selectedWilaya === 'all' || req.wilayaCode === selectedWilaya;
      const matchesCat =
        boardCategoryFilter === 'all' || req.category === boardCategoryFilter;
      const matchesQuery =
        !q ||
        req.title.toLowerCase().includes(q) ||
        req.requesterName.toLowerCase().includes(q) ||
        req.wilayaName.toLowerCase().includes(q) ||
        req.municipality.toLowerCase().includes(q);
      return matchesWilaya && matchesCat && matchesQuery;
    });
  }, [requests, selectedWilaya, boardCategoryFilter, searchQuery]);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-[#0F1F16]">
          تسجيل المواطن والمزارع وطلب الاحتياجات
        </h2>
        <p className="text-sm text-[#4A5D52] mt-1">
          سجّل حسابك كمزارع أو مواطن في أي من الولايات الـ 58، وانشر احتياجاتك من الآلات الفلاحية أو الطاقة الشمسية والبطاريات بالدينار الجزائري ليتجاوب معك المزودون القريبون.
        </p>
      </div>

      {/* Top Grid: Registration Form / Active Member Card + Submit Need Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Column 1: Citizen / Farmer Registration */}
        <div className="lg:col-span-5 bg-white border border-[#E4E8E1] rounded-xl p-6 space-y-5">
          {profile ? (
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-3 border-b border-[#EFF2ED] pb-4">
                <div className="flex items-center gap-2.5">
                  <UserCheck
                    className="w-6 h-6 text-[#15803D] shrink-0"
                    aria-hidden="true"
                  />
                  <div>
                    <div className="text-xs font-mono text-[#15803D] font-semibold">
                      حساب مسجل ومفعل · {profile.memberCode}
                    </div>
                    <h3 className="text-lg font-bold text-[#0F1F16]">
                      {profile.fullName}
                    </h3>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onResetProfile}
                  className="text-xs font-medium text-[#4A5D52] hover:text-[#0F1F16] underline"
                >
                  تعديل / تسجيل حساب آخر
                </button>
              </div>

              <dl className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <dt className="text-[#617569]">الصفة</dt>
                  <dd className="font-semibold text-[#0F1F16] mt-0.5">
                    {profile.roleType}
                  </dd>
                </div>
                <div>
                  <dt className="text-[#617569]">رقم الهاتف</dt>
                  <dd className="font-mono tabular-nums font-semibold text-[#0F1F16] mt-0.5">
                    {profile.phone}
                  </dd>
                </div>
                <div>
                  <dt className="text-[#617569]">الولاية والبلدية</dt>
                  <dd className="font-semibold text-[#0F1F16] mt-0.5">
                    {profile.wilayaCode} — {profile.wilayaName} ({profile.municipality})
                  </dd>
                </div>
                <div>
                  <dt className="text-[#617569]">حالة الكهرباء والمساحة</dt>
                  <dd className="font-semibold text-[#0F1F16] mt-0.5">
                    {profile.gridStatus} · {profile.farmAreaHectares} هكتار
                  </dd>
                </div>
              </dl>

              <div className="p-3 rounded-lg bg-[#EEF5EE] border border-[#CDE0CD] text-xs text-[#166534]">
                تم ربط ملفك بنظام طلبات الاحتياجات؛ يمكنك الآن إرسال أي طلب مباشرة وسيظهر باسمك وولايتك.
              </div>
            </div>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div className="flex items-center gap-2 border-b border-[#EFF2ED] pb-3">
                <UserPlus
                  className="w-5 h-5 text-[#15803D]"
                  aria-hidden="true"
                />
                <h3 className="text-lg font-bold text-[#0F1F16]">
                  1. تسجيل حساب مواطن أو مزارع
                </h3>
              </div>

              <div>
                <label
                  htmlFor="reg-fullname"
                  className="block text-xs font-medium text-[#4A5D52] mb-1"
                >
                  الاسم الكامل
                </label>
                <input
                  id="reg-fullname"
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="مثال: عبد الرحمن منصوري"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="reg-role"
                    className="block text-xs font-medium text-[#4A5D52] mb-1"
                  >
                    الصفة
                  </label>
                  <select
                    id="reg-role"
                    value={roleType}
                    onChange={(e) =>
                      setRoleType(e.target.value as FarmerProfile['roleType'])
                    }
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  >
                    <option value="مزارع صغير">مزارع صغير</option>
                    <option value="مواطن / مستثمرة عائلية">
                      مواطن / مستثمرة عائلية
                    </option>
                    <option value="تعاونية فلاحية">تعاونية فلاحية</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="reg-phone"
                    className="block text-xs font-medium text-[#4A5D52] mb-1"
                  >
                    رقم الهاتف (الجزائر)
                  </label>
                  <input
                    id="reg-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0550 12 34 56"
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="reg-wilaya"
                    className="block text-xs font-medium text-[#4A5D52] mb-1"
                  >
                    الولاية (58 ولاية)
                  </label>
                  <select
                    id="reg-wilaya"
                    value={regWilayaCode}
                    onChange={(e) => setRegWilayaCode(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  >
                    {ALGERIA_WILAYAS.map((w) => (
                      <option key={w.code} value={w.code}>
                        {w.code} — {w.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="reg-municipality"
                    className="block text-xs font-medium text-[#4A5D52] mb-1"
                  >
                    البلدية / المنطقة الفلاحية
                  </label>
                  <input
                    id="reg-municipality"
                    type="text"
                    required
                    value={municipality}
                    onChange={(e) => setMunicipality(e.target.value)}
                    placeholder="مثال: عين تموشنت"
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="reg-grid"
                    className="block text-xs font-medium text-[#4A5D52] mb-1"
                  >
                    الربط الكهربائي
                  </label>
                  <select
                    id="reg-grid"
                    value={gridStatus}
                    onChange={(e) =>
                      setGridStatus(
                        e.target.value as FarmerProfile['gridStatus']
                      )
                    }
                    className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  >
                    <option value="معزول / خارج الشبكة">
                      معزول / خارج الشبكة
                    </option>
                    <option value="مربوط بالشبكة الكهربائية">
                      مربوط بالشبكة الكهربائية
                    </option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="reg-area"
                    className="block text-xs font-medium text-[#4A5D52] mb-1"
                  >
                    المساحة التقريبية (هكتار)
                  </label>
                  <input
                    id="reg-area"
                    type="text"
                    value={farmAreaHectares}
                    onChange={(e) => setFarmAreaHectares(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                  />
                </div>
              </div>

              {regError && (
                <p className="text-xs font-medium text-[#DC2626]">{regError}</p>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors min-h-[42px]"
              >
                تسجيل الحساب وتفعيل الطلبات
              </button>
            </form>
          )}
        </div>

        {/* Column 2: Request Needs Form */}
        <form
          onSubmit={handleNeedSubmit}
          className="lg:col-span-7 bg-white border border-[#E4E8E1] rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between gap-2 border-b border-[#EFF2ED] pb-3">
            <div className="flex items-center gap-2">
              <ClipboardList
                className="w-5 h-5 text-[#B45309]"
                aria-hidden="true"
              />
              <h3 className="text-lg font-bold text-[#0F1F16]">
                2. تقديم طلب احتياج من المنصة
              </h3>
            </div>
            {profile && (
              <span className="text-xs text-[#15803D] font-medium">
                باسم: {profile.fullName} ({profile.wilayaName})
              </span>
            )}
          </div>

          {!profile && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#F9FBF8] border border-[#E4E8E1] rounded-lg p-3">
              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  اسم المواطن / المزارع
                </label>
                <input
                  type="text"
                  required
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="الاسم الكامل"
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#E4E8E1] rounded-md"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  الهاتف
                </label>
                <input
                  type="tel"
                  required
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  placeholder="0660 00 00 00"
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-[#E4E8E1] rounded-md"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  الولاية
                </label>
                <select
                  value={guestWilaya}
                  onChange={(e) => setGuestWilaya(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#E4E8E1] rounded-md"
                >
                  {ALGERIA_WILAYAS.map((w) => (
                    <option key={w.code} value={w.code}>
                      {w.code} — {w.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5D52] mb-1">
                  البلدية
                </label>
                <input
                  type="text"
                  required
                  value={guestMunicipality}
                  onChange={(e) => setGuestMunicipality(e.target.value)}
                  placeholder="اسم البلدية"
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#E4E8E1] rounded-md"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="need-cat"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                نوع الاحتياج المطلوب
              </label>
              <select
                id="need-cat"
                value={needCategory}
                onChange={(e) =>
                  setNeedCategory(e.target.value as NeedCategory)
                }
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              >
                {NEED_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="need-date"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                تاريخ الاحتياج
              </label>
              <input
                id="need-date"
                type="date"
                required
                value={neededDate}
                onChange={(e) => setNeededDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="need-title"
              className="block text-xs font-medium text-[#4A5D52] mb-1"
            >
              عنوان الطلب أو وصف الحاجة
            </label>
            <input
              id="need-title"
              type="text"
              required
              value={needTitle}
              onChange={(e) => setNeedTitle(e.target.value)}
              placeholder="مثال: أحتاج جرار لحراثة 3 هكتارات أو بطاريات شمسية 10 kWh لتشغيل المضخة"
              className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="need-qty"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                الكمية / المدة المطلوبة
              </label>
              <input
                id="need-qty"
                type="text"
                required
                value={quantityNeeded}
                onChange={(e) => setQuantityNeeded(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>

            <div>
              <label
                htmlFor="need-budget"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                الميزانية التقديرية (د.ج)
              </label>
              <input
                id="need-budget"
                type="number"
                min={200}
                step={100}
                value={maxBudgetDzd}
                onChange={(e) => setMaxBudgetDzd(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="need-notes"
              className="block text-xs font-medium text-[#4A5D52] mb-1"
            >
              تفاصيل إضافية (المسلك، إمكانية الدمج في مسار مجاور، الربط الكهربائي)
            </label>
            <textarea
              id="need-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="اذكر تفاصيل الوصول للمستثمرة أو نوع البطارية/المعدة المطلوبة..."
              className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
            />
          </div>

          {reqSubmittedNotice && (
            <div className="p-3 rounded-lg bg-[#EEF5EE] border border-[#CDE0CD] text-xs text-[#166534] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{reqSubmittedNotice}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 bg-[#B45309] hover:bg-[#92400E] text-white text-sm font-medium rounded-lg transition-colors min-h-[42px]"
          >
            إرسال ونشر طلب الاحتياج
          </button>
        </form>
      </div>

      {/* Bottom Section: Community Needs Board across 58 Wilayas */}
      <div className="space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 bg-white border border-[#E4E8E1] rounded-xl p-3">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-[#F4F7F3] rounded-lg">
            {(
              [
                { id: 'all', label: 'كل الطلبات' },
                { id: 'equipment_rental', label: 'معدات فلاحية' },
                { id: 'energy_battery', label: 'طاقة وبطاريات' },
                { id: 'solar_irrigation', label: 'ري شمسي' },
                { id: 'maintenance_install', label: 'صيانة وتركيب' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setBoardCategoryFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  boardCategoryFilter === tab.id
                    ? 'bg-white text-[#0F1F16] shadow-xs font-semibold'
                    : 'text-[#4A5D52] hover:text-[#0F1F16]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <select
              value={selectedWilaya}
              onChange={(e) => onSelectWilaya(e.target.value)}
              aria-label="تصفية الطلبات حسب الولاية"
              className="px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg text-[#0F1F16] focus:outline-none focus:border-[#15803D] min-w-[200px]"
            >
              <option value="all">كل الولايات (58 ولاية)</option>
              {ALGERIA_WILAYAS.map((w) => (
                <option key={w.code} value={w.code}>
                  {w.code} — {w.name}
                </option>
              ))}
            </select>

            <div className="relative min-w-[220px]">
              <Search
                className="w-4 h-4 text-[#617569] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث في طلبات المواطنين..."
                className="w-full pr-9 pl-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>
          </div>
        </div>

        {filteredRequests.length === 0 ? (
          <div className="bg-white border border-[#E4E8E1] rounded-xl p-8 text-center space-y-2">
            <p className="text-base font-semibold text-[#0F1F16]">
              لا توجد طلبات مسجلة مطابقة للفلتر الحالي
            </p>
            <button
              type="button"
              onClick={() => {
                setBoardCategoryFilter('all');
                setSearchQuery('');
                onSelectWilaya('all');
              }}
              className="px-4 py-2 text-sm font-medium bg-[#15803D] text-white rounded-lg hover:bg-[#166534]"
            >
              عرض كل طلبات الولايات الـ 58
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredRequests.map((req) => (
              <article
                key={req.id}
                className="bg-white border border-[#E4E8E1] rounded-xl p-5 flex flex-col justify-between gap-4"
              >
                <div className="space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#4A5D52]">
                    <span className="font-semibold text-[#15803D]">
                      {req.categoryLabel} · {req.wilayaCode} {req.wilayaName}
                    </span>
                    <span className="font-mono tabular-nums text-[#617569]">
                      {req.id}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-[#0F1F16] leading-snug">
                    {req.title}
                  </h4>

                  <p className="text-xs text-[#4A5D52] leading-relaxed">
                    {req.notes}
                  </p>

                  <div className="pt-2 border-t border-[#EFF2ED] space-y-1 text-xs text-[#4A5D52]">
                    <div>
                      مقدم الطلب: <strong className="text-[#0F1F16]">{req.requesterName}</strong> ({req.requesterRole})
                    </div>
                    <div>
                      البلدية: {req.municipality} {req.isOffGrid ? '· موقع معزول عن الشبكة' : ''}
                    </div>
                    <div className="font-mono tabular-nums">
                      الكمية: {req.quantityNeeded} · الموعد: {req.neededDate}
                    </div>
                    <div className="inline-flex items-center gap-1 font-mono tabular-nums text-[#0F1F16]">
                      <Phone className="w-3 h-3 text-[#15803D]" aria-hidden="true" />
                      <span>{req.requesterPhone}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#EFF2ED] space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#617569]">الميزانية التقديرية</span>
                    <span className="text-base font-bold font-mono tabular-nums text-[#0F1F16]">
                      {formatDzd(req.maxBudgetDzd)}
                    </span>
                  </div>

                  {req.status === 'تمت مطابقة مزود' ? (
                    <div className="p-2.5 rounded-lg bg-[#EEF5EE] text-xs font-medium text-[#166534] flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>تمت مطابقة مزود: {req.matchedProvider}</span>
                    </div>
                  ) : matchingRequestId === req.id ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={responderName}
                        onChange={(e) => setResponderName(e.target.value)}
                        placeholder="اسمك أو مؤسستك لتلبية الطلب"
                        className="flex-1 px-2.5 py-1.5 text-xs bg-[#F7F9F6] border border-[#E4E8E1] rounded-md"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (!responderName.trim()) return;
                          onFulfillRequest(req.id, responderName.trim());
                          setMatchingRequestId(null);
                          setResponderName('');
                        }}
                        className="px-3 py-1.5 text-xs font-medium bg-[#15803D] text-white rounded-md whitespace-nowrap"
                      >
                        تأكيد
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setMatchingRequestId(req.id);
                        setResponderName('');
                      }}
                      className="w-full py-2 text-xs font-medium bg-[#F7F9F6] hover:bg-[#ECF3ED] text-[#0F1F16] border border-[#D7E0D5] rounded-lg transition-colors"
                    >
                      تلبية الطلب وتقديم عرض
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
