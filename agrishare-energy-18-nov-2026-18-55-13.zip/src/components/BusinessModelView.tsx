import React, { useState } from 'react';
import { ALGERIA_WILAYAS, formatDzd } from '../data/algeriaWilayas';
import { BookingRecord } from '../types/agrishare';

interface BusinessModelViewProps {
  bookings: BookingRecord[];
}

export const BusinessModelView: React.FC<BusinessModelViewProps> = ({
  bookings,
}) => {
  const [monthlyMachineryHours, setMonthlyMachineryHours] = useState(120);
  const [monthlyEnergyKwh, setMonthlyEnergyKwh] = useState(1800);
  const [insuranceAdoptionPct, setInsuranceAdoptionPct] = useState(65);

  const avgHourRate = 3500;
  const avgKwhRate = 12;
  const equipmentGmv = monthlyMachineryHours * avgHourRate;
  const energyGmv = monthlyEnergyKwh * avgKwhRate;
  const totalGmv = equipmentGmv + energyGmv;
  const brokerageRevenue = totalGmv * 0.06;
  const microInsuranceRevenue =
    (monthlyMachineryHours / 4) * (insuranceAdoptionPct / 100) * 450;
  const maintenanceReferralRevenue = 600 * 6;
  const totalPlatformRevenue =
    brokerageRevenue + microInsuranceRevenue + maintenanceReferralRevenue;

  const sessionTotalCommission = bookings.reduce(
    (sum, b) => sum + b.platformCommission,
    0
  );
  const sessionTotalInsurance = bookings.reduce(
    (sum, b) => sum + b.microInsuranceFee,
    0
  );
  const sessionTotalVolume = bookings.reduce((sum, b) => sum + b.totalPaid, 0);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-[#0F1F16]">
          نموذج العمل واستدامة المنصة عبر ولايات الجزائر
        </h2>
        <p className="text-sm text-[#4A5D52] mt-1">
          مصادر دخل عادلة بالدينار الجزائري تدعم الفلاحين الصغار وتضمن استمرارية تشغيل المنصة في جميع الولايات الـ 58.
        </p>
      </div>

      {/* 2 Revenue Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <article className="bg-white border border-[#E4E8E1] rounded-xl p-6 space-y-3">
          <div className="text-xs font-mono text-[#15803D] font-semibold">
            01. عمولة الوساطة الرقمية
          </div>
          <h3 className="text-lg font-bold text-[#0F1F16]">
            نسبة 6% شفافة على المعاملات الناجحة
          </h3>
          <p className="text-sm text-[#4A5D52] leading-relaxed">
            تُقتطع تلقائياً فقط عند إتمام كراء المعدات الفلاحية بالساعة أو الهكتار، أو عند بيع فائض الطاقة الشمسية وتعبئة البطاريات بالدينار الجزائري، دون اشتراكات شهرية مسبقة.
          </p>
          <div className="pt-2 border-t border-[#EFF2ED] text-xs text-[#4A5D52] font-mono tabular-nums">
            عائد الجرارات: 94% للمالك · عائد الطاقة والبطاريات: 94% للمنتج
          </div>
        </article>

        <article className="bg-white border border-[#E4E8E1] rounded-xl p-6 space-y-3">
          <div className="text-xs font-mono text-[#B45309] font-semibold">
            02. خدمات القيمة المضافة والتأمين المصغر
          </div>
          <h3 className="text-lg font-bold text-[#0F1F16]">
            حماية المعدات والبطاريات وشبكة الصيانة الوطنية
          </h3>
          <p className="text-sm text-[#4A5D52] leading-relaxed">
            توفير خطط تأمين مصغر اختيارية لتغطية المخاطر أثناء نقل واستخدام الآلات والبطاريات المتنقلة، إلى جانب ربط الفلاحين بفرق صيانة وتركيب معتمدة عبر 58 ولاية.
          </p>
          <div className="pt-2 border-t border-[#EFF2ED] text-xs text-[#4A5D52] font-mono tabular-nums">
            تأمين مصغر: 450 د.ج للطلب · رسوم ربط الصيانة: 600 د.ج / زيارة
          </div>
        </article>
      </div>

      {/* Interactive Economic Simulator */}
      <div className="bg-white border border-[#E4E8E1] rounded-xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EFF2ED] pb-4">
          <div>
            <h3 className="text-lg font-bold text-[#0F1F16]">
              محاكي الاستدامة المالية لولاية واحدة (شهرياً بالدينار الجزائري)
            </h3>
            <p className="text-xs text-[#4A5D52] mt-0.5">
              حرّك المؤشرات لمعاينة توازن العائد بين الفلاحين واستدامة المنصة.
            </p>
          </div>
          <div className="text-left font-mono tabular-nums">
            <span className="text-xs text-[#617569] block">إجمالي الدخل المتوقع للمنصة</span>
            <span className="text-2xl font-bold text-[#15803D]">
              {formatDzd(totalPlatformRevenue)} / شهر
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="flex justify-between text-xs font-medium mb-2">
              <label htmlFor="sim-hours" className="text-[#0F1F16]">
                ساعات كراء المعدات
              </label>
              <span className="font-mono tabular-nums text-[#15803D]">
                {monthlyMachineryHours} ساعة
              </span>
            </div>
            <input
              id="sim-hours"
              type="range"
              min={20}
              max={400}
              step={10}
              value={monthlyMachineryHours}
              onChange={(e) => setMonthlyMachineryHours(Number(e.target.value))}
              className="w-full accent-[#15803D]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-medium mb-2">
              <label htmlFor="sim-energy" className="text-[#0F1F16]">
                الطاقة والبطاريات المتبادلة
              </label>
              <span className="font-mono tabular-nums text-[#B45309]">
                {monthlyEnergyKwh} kWh
              </span>
            </div>
            <input
              id="sim-energy"
              type="range"
              min={300}
              max={6000}
              step={100}
              value={monthlyEnergyKwh}
              onChange={(e) => setMonthlyEnergyKwh(Number(e.target.value))}
              className="w-full accent-[#D97706]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-medium mb-2">
              <label htmlFor="sim-ins" className="text-[#0F1F16]">
                نسبة تفعيل التأمين المصغر
              </label>
              <span className="font-mono tabular-nums text-[#0F1F16]">
                {insuranceAdoptionPct}%
              </span>
            </div>
            <input
              id="sim-ins"
              type="range"
              min={10}
              max={100}
              step={5}
              value={insuranceAdoptionPct}
              onChange={(e) => setInsuranceAdoptionPct(Number(e.target.value))}
              className="w-full accent-[#15803D]"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-[#EFF2ED]">
          <div>
            <div className="text-xs text-[#617569]">حجم التبادل الكلي</div>
            <div className="text-lg font-bold font-mono tabular-nums text-[#0F1F16]">
              {formatDzd(totalGmv)}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#617569]">عمولة الوساطة (6%)</div>
            <div className="text-lg font-bold font-mono tabular-nums text-[#15803D]">
              {formatDzd(brokerageRevenue)}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#617569]">عوائد التأمين المصغر</div>
            <div className="text-lg font-bold font-mono tabular-nums text-[#B45309]">
              {formatDzd(microInsuranceRevenue)}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#617569]">عوائد شبكة الصيانة</div>
            <div className="text-lg font-bold font-mono tabular-nums text-[#0F1F16]">
              {formatDzd(maintenanceReferralRevenue)}
            </div>
          </div>
        </div>
      </div>

      {/* Live Session Ledger */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-lg font-bold text-[#0F1F16]">
            سجل المعاملات والعمولات الحالية
          </h3>
          <div className="text-xs text-[#4A5D52] font-mono tabular-nums">
            الإجمالي: {formatDzd(sessionTotalVolume)} · عمولة المنصة:{' '}
            {formatDzd(sessionTotalCommission)} · تأمين مصغر:{' '}
            {formatDzd(sessionTotalInsurance)}
          </div>
        </div>

        <div className="bg-white border border-[#E4E8E1] rounded-xl overflow-x-auto">
          <table className="w-full text-right border-collapse min-w-[680px]">
            <thead>
              <tr className="border-b border-[#E4E8E1] bg-[#F9FBF8] text-xs font-semibold text-[#4A5D52]">
                <th className="py-3 px-4">رقم العملية</th>
                <th className="py-3 px-4">الخدمة / الأصل</th>
                <th className="py-3 px-4">المزود</th>
                <th className="py-3 px-4">الكمية / التفاصيل</th>
                <th className="py-3 px-4">التأمين المصغر</th>
                <th className="py-3 px-4">عمولة المنصة</th>
                <th className="py-3 px-4">الإجمالي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFF2ED] text-sm">
              {bookings.map((b) => (
                <tr key={b.id} className="hover:bg-[#F7F9F6]">
                  <td className="py-3 px-4 font-mono tabular-nums text-xs text-[#4A5D52]">
                    {b.id}
                  </td>
                  <td className="py-3 px-4 font-medium text-[#0F1F16]">
                    {b.itemTitle}
                  </td>
                  <td className="py-3 px-4 text-[#4A5D52]">{b.providerName}</td>
                  <td className="py-3 px-4 text-xs text-[#4A5D52]">
                    {b.quantityLabel}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums text-xs">
                    {formatDzd(b.microInsuranceFee)}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums text-xs text-[#15803D]">
                    {formatDzd(b.platformCommission)}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums font-bold text-[#0F1F16]">
                    {formatDzd(b.totalPaid)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* National 58-Wilaya Coverage Directory */}
      <div className="bg-white border border-[#E4E8E1] rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-lg font-bold text-[#0F1F16]">
              التغطية الوطنية الشاملة — 58 ولاية جزائرية
            </h3>
            <p className="text-xs text-[#4A5D52] mt-0.5">
              تعمل شبكة AgriShare Energy في كافة ولايات الوطن من الشمال والهضاب العليا إلى الواحات والجنوب الكبير.
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums font-semibold text-[#15803D]">
            58 / 58 ولاية نشطة
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2 text-xs">
          {ALGERIA_WILAYAS.map((w) => (
            <div
              key={w.code}
              className="px-2.5 py-1.5 rounded-md bg-[#F7F9F6] border border-[#E4E8E1] text-[#0F1F16] truncate"
              title={`${w.code} — ${w.name} (${w.zone})`}
            >
              <span className="font-mono text-[#617569] ml-1">{w.code}</span>
              <span>{w.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
