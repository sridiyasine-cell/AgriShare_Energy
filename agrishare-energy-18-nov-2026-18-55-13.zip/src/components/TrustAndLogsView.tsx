import React, { useState } from 'react';
import { CheckCircle2, ShieldCheck, Star, Wrench } from 'lucide-react';
import { formatDzd } from '../data/algeriaWilayas';
import {
  DigitalLogEntry,
  FarmerReview,
  MaintenanceProvider,
} from '../types/agrishare';

interface TrustAndLogsViewProps {
  logs: DigitalLogEntry[];
  reviews: FarmerReview[];
  maintenanceProviders: MaintenanceProvider[];
  onAddReview: (review: Omit<FarmerReview, 'id' | 'dateLabel' | 'verifiedBookingCode'>) => void;
  onBookMaintenance: (provider: MaintenanceProvider) => void;
}

export const TrustAndLogsView: React.FC<TrustAndLogsViewProps> = ({
  logs,
  reviews,
  maintenanceProviders,
  onAddReview,
  onBookMaintenance,
}) => {
  const [logFilter, setLogFilter] = useState<'all' | 'معدة زراعية' | 'محطة طاقة وبطاريات'>('all');
  const [authorName, setAuthorName] = useState('');
  const [authorFarm, setAuthorFarm] = useState('');
  const [targetName, setTargetName] = useState('جرار John Deere 6155M');
  const [targetType, setTargetType] = useState<'معدة' | 'طاقة وبطاريات'>('معدة');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const filteredLogs = logs.filter(
    (entry) => logFilter === 'all' || entry.assetType === logFilter
  );

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !authorFarm.trim() || !comment.trim()) return;
    onAddReview({
      authorName: authorName.trim(),
      authorFarm: authorFarm.trim(),
      targetName: targetName.trim(),
      targetType,
      rating,
      comment: comment.trim(),
    });
    setAuthorName('');
    setAuthorFarm('');
    setComment('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 4000);
  };

  return (
    <div className="space-y-8">
      {/* 1. Digital Technical Reliability Logs Table */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-[#0F1F16]">
              السجل الرقمي والموثوقية الفنية
            </h2>
            <p className="text-sm text-[#4A5D52] mt-1">
              متابعة دقيقة لساعات عمل الآلات، دورات شحن البطاريات، وتاريخ آخر فحص ميداني لضمان الأمان والجودة قبل التشغيل.
            </p>
          </div>

          <div className="inline-flex items-center gap-1 p-1 bg-[#EBF0E9] rounded-lg self-start">
            {(['all', 'معدة زراعية', 'محطة طاقة وبطاريات'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setLogFilter(tab)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  logFilter === tab
                    ? 'bg-white text-[#0F1F16] shadow-xs font-semibold'
                    : 'text-[#4A5D52] hover:text-[#0F1F16]'
                }`}
              >
                {tab === 'all' ? 'جميع الأصول' : tab}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white border border-[#E4E8E1] rounded-xl overflow-x-auto">
          <table className="w-full text-right border-collapse min-w-[720px]">
            <thead>
              <tr className="border-b border-[#E4E8E1] bg-[#F9FBF8] text-xs font-semibold text-[#4A5D52]">
                <th className="py-3 px-4">الرمز الفني</th>
                <th className="py-3 px-4">الأصل / المحطة</th>
                <th className="py-3 px-4">المالك</th>
                <th className="py-3 px-4">القراءة الفنية</th>
                <th className="py-3 px-4">آخر فحص</th>
                <th className="py-3 px-4">الحالة المعتمدة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFF2ED] text-sm">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-[#F7F9F6] transition-colors">
                  <td className="py-3 px-4 font-mono tabular-nums text-xs text-[#4A5D52]">
                    {log.assetCode}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-[#0F1F16]">{log.assetName}</div>
                    <div className="text-xs text-[#617569]">{log.assetType}</div>
                  </td>
                  <td className="py-3 px-4 text-[#4A5D52]">{log.ownerName}</td>
                  <td className="py-3 px-4 font-mono tabular-nums text-xs text-[#0F1F16]">
                    {log.metricValue}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums text-xs text-[#4A5D52]">
                    {log.lastCheckDate}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                        log.conditionStatus === 'موثوق ومفحوص'
                          ? 'text-[#15803D]'
                          : 'text-[#B45309]'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>{log.conditionStatus}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2. Peer Reputation & Verified Farmer Reviews */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-4">
          <div>
            <h3 className="text-xl font-bold text-[#0F1F16]">
              نظام السمعة والثقة الرقمية بين المزارعين
            </h3>
            <p className="text-sm text-[#4A5D52] mt-1">
              تقييمات متبادلة وموثقة بأرقام الحجز لقياس التزام أصحاب المعدات وجودة البطاريات المعبأة.
            </p>
          </div>

          <div className="space-y-3">
            {reviews.map((rev) => (
              <article
                key={rev.id}
                className="bg-white border border-[#E4E8E1] rounded-xl p-5 space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#4A5D52]">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-[#0F1F16]">
                      {rev.authorName}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{rev.authorFarm}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      مرجع {rev.verifiedBookingCode}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-[#D97706] font-mono tabular-nums font-semibold">
                    <Star className="w-3.5 h-3.5 fill-[#D97706]" aria-hidden="true" />
                    <span>{rev.rating.toFixed(1)}</span>
                  </div>
                </div>

                <div className="text-xs font-medium text-[#15803D]">
                  {rev.targetType} · {rev.targetName}
                </div>

                <p className="text-sm text-[#0F1F16] leading-relaxed">
                  {rev.comment}
                </p>

                <div className="text-xs text-[#617569] font-mono tabular-nums">
                  {rev.dateLabel}
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* Add Verified Review Form */}
        <form
          onSubmit={handleReviewSubmit}
          className="lg:col-span-5 bg-white border border-[#E4E8E1] rounded-xl p-5 space-y-4"
        >
          <div className="flex items-center gap-2 text-base font-bold text-[#0F1F16]">
            <ShieldCheck className="w-5 h-5 text-[#15803D]" aria-hidden="true" />
            <span>أضف تقييماً موثقاً بعد التجربة</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="rev-author"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                اسم المزارع
              </label>
              <input
                id="rev-author"
                type="text"
                required
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="مثال: ناصر العتيبي"
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>

            <div>
              <label
                htmlFor="rev-farm"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                اسم المزرعة / المنطقة
              </label>
              <input
                id="rev-farm"
                type="text"
                required
                value={authorFarm}
                onChange={(e) => setAuthorFarm(e.target.value)}
                placeholder="مثال: مزرعة السهل 4"
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="rev-type"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                نوع المعاملة
              </label>
              <select
                id="rev-type"
                value={targetType}
                onChange={(e) =>
                  setTargetType(e.target.value as 'معدة' | 'طاقة وبطاريات')
                }
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              >
                <option value="معدة">استئجار معدة زراعية</option>
                <option value="طاقة وبطاريات">شراء طاقة / تعبئة بطاريات</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="rev-rating"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                التقييم (من 5)
              </label>
              <select
                id="rev-rating"
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              >
                <option value={5}>5 نجوم — التزام وجودة ممتازة</option>
                <option value={4}>4 نجوم — جيد جداً</option>
                <option value={3}>3 نجوم — مقبول</option>
              </select>
            </div>
          </div>

          <div>
            <label
              htmlFor="rev-target"
              className="block text-xs font-medium text-[#4A5D52] mb-1"
            >
              المعدة أو محطة الطاقة المقيمة
            </label>
            <input
              id="rev-target"
              type="text"
              required
              value={targetName}
              onChange={(e) => setTargetName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
            />
          </div>

          <div>
            <label
              htmlFor="rev-comment"
              className="block text-xs font-medium text-[#4A5D52] mb-1"
            >
              ملاحظاتك الميدانية
            </label>
            <textarea
              id="rev-comment"
              rows={3}
              required
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="اكتب عن التزام المالك، كفاءة البطارية، أو جاهزية الآلة..."
              className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
            />
          </div>

          {reviewSubmitted && (
            <p className="text-xs font-medium text-[#15803D]">
              تم توثيق التقييم وإضافته إلى سجل الثقة بنجاح.
            </p>
          )}

          <button
            type="submit"
            className="w-full px-4 py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors min-h-[42px]"
          >
            نشر التقييم الموثق
          </button>
        </form>
      </div>

      {/* 3. Certified Maintenance & Installation Network */}
      <div className="space-y-4 pt-2">
        <div>
          <h3 className="text-xl font-bold text-[#0F1F16]">
            شبكة الصيانة والتركيب المعتمدة
          </h3>
          <p className="text-sm text-[#4A5D52] mt-1">
            ربط مباشر بفرق فنية معتمدة لصيانة الآلات وتركيب محطات الطاقة والبطاريات مقابل رسوم خدمة واضحة.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {maintenanceProviders.map((provider) => (
            <article
              key={provider.id}
              className="bg-white border border-[#E4E8E1] rounded-xl p-5 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="text-xs text-[#4A5D52]">
                  {provider.specialty} · {provider.region}
                </div>
                <h4 className="text-base font-bold text-[#0F1F16]">
                  {provider.name}
                </h4>
                <div className="text-xs text-[#4A5D52] flex items-center gap-3 font-mono tabular-nums">
                  <span>استجابة: {provider.responseTime}</span>
                  <span>·</span>
                  <span>
                    تقييم {provider.rating.toFixed(1)} ({provider.completedJobs})
                  </span>
                </div>
              </div>

              <div className="pt-3 border-t border-[#EFF2ED] flex items-center justify-between gap-3">
                <div className="font-mono tabular-nums text-base font-bold text-[#0F1F16]">
                  {formatDzd(provider.baseFee)}{' '}
                  <span className="text-xs font-sans font-normal text-[#4A5D52]">
                    / زيارة فحص
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onBookMaintenance(provider)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#F7F9F6] hover:bg-[#ECF3ED] text-[#0F1F16] border border-[#D7E0D5] rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  <Wrench className="w-3.5 h-3.5 text-[#15803D]" aria-hidden="true" />
                  <span>طلب فني معتمد</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};
