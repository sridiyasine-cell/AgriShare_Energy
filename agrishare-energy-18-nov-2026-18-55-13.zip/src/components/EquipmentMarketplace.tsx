import React, { useMemo, useState } from 'react';
import { MapPin, Search, Star, Wrench } from 'lucide-react';
import { ALGERIA_WILAYAS, formatDzd } from '../data/algeriaWilayas';
import {
  EquipmentCategory,
  EquipmentItem,
  PricingUnit,
} from '../types/agrishare';
import { ResilientImage } from './ResilientImage';

interface EquipmentMarketplaceProps {
  items: EquipmentItem[];
  selectedWilaya: string;
  onSelectWilaya: (wilayaCode: string) => void;
  onBookEquipment: (item: EquipmentItem, preferredUnit: PricingUnit) => void;
  onInspectRoute: (routeId: string) => void;
  onOpenPublishForWilaya: () => void;
}

const CATEGORIES: { id: EquipmentCategory; label: string }[] = [
  { id: 'all', label: 'الكل' },
  { id: 'tractor', label: 'جرارات' },
  { id: 'harvester', label: 'حصادات' },
  { id: 'irrigation', label: 'مضخات ري' },
  { id: 'seeder', label: 'بذارات' },
];

export const EquipmentMarketplace: React.FC<EquipmentMarketplaceProps> = ({
  items,
  selectedWilaya,
  onSelectWilaya,
  onBookEquipment,
  onInspectRoute,
  onOpenPublishForWilaya,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] =
    useState<EquipmentCategory>('all');
  const [pricingUnit, setPricingUnit] = useState<PricingUnit>('hour');

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return items.filter((item) => {
      const matchesWilaya =
        selectedWilaya === 'all' || item.wilayaCode === selectedWilaya;
      const matchesCategory =
        selectedCategory === 'all' || item.category === selectedCategory;
      const matchesQuery =
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.ownerName.toLowerCase().includes(q) ||
        item.ownerRegion.toLowerCase().includes(q) ||
        item.wilayaName.toLowerCase().includes(q) ||
        item.categoryLabel.toLowerCase().includes(q);
      return matchesWilaya && matchesCategory && matchesQuery;
    });
  }, [items, selectedWilaya, searchQuery, selectedCategory]);

  const activeWilayaObj = ALGERIA_WILAYAS.find((w) => w.code === selectedWilaya);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    onSelectWilaya('all');
  };

  return (
    <div className="space-y-6">
      {/* Section Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#0F1F16]">
            سوق مشاركة المعدات الفلاحية في الجزائر
          </h2>
          <p className="text-sm text-[#4A5D52] mt-1">
            استأجر الجرارات والحصادات ومضخات الري بالدينار الجزائري (د.ج) بالساعة أو الهكتار عبر 58 ولاية.
          </p>
        </div>

        {/* Pricing unit segmented control */}
        <div
          className="inline-flex items-center gap-1 p-1 bg-[#EBF0E9] rounded-lg self-start lg:self-auto"
          role="group"
          aria-label="وحدة التسعير"
        >
          <button
            type="button"
            onClick={() => setPricingUnit('hour')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              pricingUnit === 'hour'
                ? 'bg-white text-[#0F1F16] shadow-xs'
                : 'text-[#4A5D52] hover:text-[#0F1F16]'
            }`}
          >
            التسعير بالساعة
          </button>
          <button
            type="button"
            onClick={() => setPricingUnit('hectare')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              pricingUnit === 'hectare'
                ? 'bg-white text-[#0F1F16] shadow-xs'
                : 'text-[#4A5D52] hover:text-[#0F1F16]'
            }`}
          >
            التسعير بالهكتار
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-white border border-[#E4E8E1] rounded-xl p-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#F4F7F3] rounded-lg">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === cat.id
                  ? 'bg-white text-[#15803D] shadow-xs font-semibold'
                  : 'text-[#4A5D52] hover:text-[#0F1F16]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <select
            value={selectedWilaya}
            onChange={(e) => onSelectWilaya(e.target.value)}
            aria-label="تصفية حسب الولاية"
            className="px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg text-[#0F1F16] focus:outline-none focus:border-[#15803D] min-w-[200px]"
          >
            <option value="all">كل الولايات (58 ولاية)</option>
            {ALGERIA_WILAYAS.map((w) => (
              <option key={w.code} value={w.code}>
                {w.code} — {w.name}
              </option>
            ))}
          </select>

          <div className="relative min-w-[240px]">
            <Search
              className="w-4 h-4 text-[#617569] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث باسم المعدة، الولاية، أو المالك..."
              aria-label="البحث في المعدات الفلاحية"
              className="w-full pr-9 pl-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg text-[#0F1F16] placeholder:text-[#617569] focus:outline-none focus:border-[#15803D]"
            />
          </div>
        </div>
      </div>

      {/* Empty State */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-[#E4E8E1] rounded-xl p-10 text-center space-y-3">
          <p className="text-base font-semibold text-[#0F1F16]">
            {activeWilayaObj
              ? `لا توجد معدات مضافة حالياً في ولاية ${activeWilayaObj.name} (${activeWilayaObj.code}) ضمن هذا التصنيف`
              : 'لا توجد معدات مطابقة لمعايير البحث الحالية'}
          </p>
          <p className="text-sm text-[#4A5D52]">
            شبكة AgriShare Energy مفتوحة في كل ولايات الجزائر الـ 58. يمكنك إضافة معدة في هذه الولاية أو عرض كل الولايات.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={onOpenPublishForWilaya}
              className="px-4 py-2 text-sm font-medium bg-[#15803D] text-white rounded-lg hover:bg-[#166534] transition-colors"
            >
              سجّل معدة في هذه الولاية
            </button>
            <button
              type="button"
              onClick={resetFilters}
              className="px-4 py-2 text-sm font-medium bg-[#F7F9F6] text-[#0F1F16] border border-[#D7E0D5] rounded-lg hover:bg-[#ECF3ED] transition-colors"
            >
              عرض كل الولايات الـ 58
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredItems.map((item) => {
            const activePrice =
              pricingUnit === 'hour' ? item.pricePerHour : item.pricePerHectare;
            const unitLabel = pricingUnit === 'hour' ? 'ساعة' : 'هكتار';

            return (
              <article
                key={item.id}
                className="bg-white border border-[#E4E8E1] rounded-xl overflow-hidden flex flex-col justify-between transition-colors hover:border-[#C5D1C3]"
              >
                <div>
                  <div className="aspect-[16/9] bg-[#EEF2EC] overflow-hidden relative">
                    <ResilientImage
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover"
                      fallbackType="equipment"
                    />
                  </div>

                  <div className="p-5 space-y-3">
                    {/* Unboxed Metadata Line */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#4A5D52]">
                      <span className="font-medium text-[#15803D]">
                        {item.categoryLabel}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.ownerRegion}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {item.distanceKm} كم
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.technicalStatus}</span>
                    </div>

                    <h3 className="text-lg font-bold text-[#0F1F16] leading-snug">
                      {item.name}
                    </h3>

                    <p className="text-sm text-[#4A5D52] leading-relaxed line-clamp-2">
                      {item.description}
                    </p>

                    {/* Technical & Trust Summary Row */}
                    <div className="pt-2 border-t border-[#EFF2ED] grid grid-cols-3 gap-3 text-xs">
                      <div>
                        <span className="text-[#617569] block">المالك والموثوقية</span>
                        <span className="font-medium text-[#0F1F16] inline-flex items-center gap-1 mt-0.5">
                          <Star
                            className="w-3.5 h-3.5 text-[#D97706] fill-[#D97706]"
                            aria-hidden="true"
                          />
                          <span className="font-mono tabular-nums">
                            {item.rating.toFixed(1)}
                          </span>
                          <span className="text-[#617569]">
                            ({item.reviewsCount})
                          </span>
                        </span>
                      </div>

                      <div>
                        <span className="text-[#617569] block">السجل الفني</span>
                        <span className="font-medium text-[#0F1F16] inline-flex items-center gap-1 mt-0.5 font-mono tabular-nums">
                          <Wrench className="w-3.5 h-3.5 text-[#4A5D52]" aria-hidden="true" />
                          {item.operatingHours} ساعة
                        </span>
                      </div>

                      <div>
                        <span className="text-[#617569] block">القدرة</span>
                        <span className="font-medium text-[#0F1F16] mt-0.5 block">
                          {item.horsepower}
                        </span>
                      </div>
                    </div>

                    {/* Smart Route Link */}
                    <div className="pt-2 flex items-center justify-between gap-2 text-xs text-[#4A5D52]">
                      <span className="inline-flex items-center gap-1.5 truncate">
                        <MapPin className="w-3.5 h-3.5 text-[#15803D] shrink-0" aria-hidden="true" />
                        <span className="truncate">{item.nearestRouteName}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => onInspectRoute(item.nearestRouteId)}
                        className="text-[#15803D] hover:underline font-medium whitespace-nowrap shrink-0"
                      >
                        معاينة المسار
                      </button>
                    </div>
                  </div>
                </div>

                {/* Card Footer: Price in DZD + Booking CTA */}
                <div className="px-5 py-4 bg-[#F9FBF8] border-t border-[#E4E8E1] flex items-center justify-between gap-4">
                  <div>
                    <div className="text-xs text-[#617569]">التكلفة المعتمدة</div>
                    <div className="text-lg font-bold text-[#0F1F16] font-mono tabular-nums">
                      {formatDzd(activePrice)}{' '}
                      <span className="text-xs font-sans font-normal text-[#4A5D52]">
                        / {unitLabel}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onBookEquipment(item, pricingUnit)}
                    className="px-4 py-2 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
                  >
                    حجز وتفاصيل المعدة
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
