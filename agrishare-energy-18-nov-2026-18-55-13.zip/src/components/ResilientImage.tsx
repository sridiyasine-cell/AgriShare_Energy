import React, { useState } from 'react';
import { Sun, Tractor } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackType?: 'equipment' | 'energy';
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  className = '',
  fallbackType = 'equipment',
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-[#ECF3ED] to-[#E2ECE4] text-[#166534] p-6 ${className}`}
        role="img"
        aria-label={alt}
      >
        {fallbackType === 'energy' ? (
          <Sun className="w-8 h-8 opacity-70" />
        ) : (
          <Tractor className="w-8 h-8 opacity-70" />
        )}
        <span className="text-xs font-medium text-center text-[#1F3A2A]/80 line-clamp-2">
          {alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
};
