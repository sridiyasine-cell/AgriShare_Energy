import React, { useMemo, useState } from 'react';
import { BatteryCharging, Search, Star, Zap } from 'lucide-react';
import { ALGERIA_WILAYAS, formatDzd } from '../data/algeriaWilayas';
import { EnergyDeliveryMode, EnergyOffer } from '../types/agrishare';
import { ResilientImage } from './ResilientImage';

interface EnergyMarketplaceProps {
  offers: EnergyOffer[];
  selectedWilaya: string;
  onSelectWilaya: (wilayaCode: string) => void;
  onOrderEnergy: (offer: EnergyOffer) => void;
  onOpenPublishForWilaya: () => void;
}

const DELIVERY_MODES: { id: EnergyDeliveryMode; label: string }[] = [
  { id: 'all', label: 'جميع الخيارات' },
  { id: 'battery_pickup', label: 'تعبئة واستلام بطارية' },
  { id: 'battery_delivery', label: 'توصيل للحقل المعزول' },
  { id: 'direct_grid', label: 'ربط مباشر بين الحقول' },
];

export const EnergyMarketplace: React.FC<EnergyMarketplaceProps> = ({
  offers,
  selectedWilaya,
  onSelectWilaya,
  onOrderEnergy,
  onOpenPublishForWilaya,
}) => {
  const [selectedMode, setSelectedMode] = useState<EnergyDeliveryMode>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredOffers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return offers.filter((offer) => {
      const matchesWilaya =
        selectedWilaya === 'all' || offer.wilayaCode === selectedWilaya;
      const matchesMode =
        selectedMode === 'all' || offer.deliveryMode === selectedMode;
      const matchesQuery =
        !q ||
        offer.title.toLowerCase().includes(q) ||
        offer.providerName.toLowerCase().includes(q) ||
        offer.wilayaName.toLowerCase().includes(q) ||
        offer.region.toLowerCase().includes(q);
      return matchesWilaya && matchesMode && matchesQuery;
    });
  }, [offers, selectedWilaya, selectedMode, searchQuery]);

  const activeWilayaObj = ALGERIA_WILAYAS.find((w) => w.code === selectedWilaya);

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#0F1F16]">
            سوق فائض الطاقة الشمسية وتعبئة البطاريات في الجزائر
          </h2>
          <p className="text-sm text-[#4A5D52] mt-1">
            تبادل فائض الطاقة الشمسية بالدينار الجزائري عبر الربط المباشر أو تعبئة البطاريات للمستثمرات المعزولة في كافة الولايات الـ 58.
          </p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-white border border-[#E4E8E1] rounded-xl p-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#F4F7F3] rounded-lg">
          {DELIVERY_MODES.map((mode) => (
            <button
              key={mode.id}
              type="button"
              onClick={() => setSelectedMode(mode.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedMode === mode.id
                  ? 'bg-white text-[#B45309] shadow-xs font-semibold'
                  : 'text-[#4A5D52] hover:text-[#0F1F16]'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <select
            value={selectedWilaya}
            onChange={(e) => onSelectWilaya(e.target.value)}
            aria-label="تصفية عروض الطاقة حسب الولاية"
            className="px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg text-[#0F1F16] focus:outline-none focus:border-[#D97706] min-w-[200px]"
          >
            <option value="all">كل الولايات (58 ولاية)</option>
            {ALGERIA_WILAYAS.map((w) => (
              <option key={w.code} value={w.code}>
                {w.code} — {w.name}
              </option>
            ))}
          </select>

          <div className="relative min-w-[240px]">
            <Search
              className="w-4 h-4 text-[#617569] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالولاية أو محطة الطاقة..."
              aria-label="البحث في عروض الطاقة الشمسية"
              className="w-full pr-9 pl-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg text-[#0F1F16] placeholder:text-[#617569] focus:outline-none focus:border-[#D97706]"
            />
          </div>
        </div>
      </div>

      {filteredOffers.length === 0 ? (
        <div className="bg-white border border-[#E4E8E1] rounded-xl p-10 text-center space-y-3">
          <p className="text-base font-semibold text-[#0F1F16]">
            {activeWilayaObj
              ? `لا توجد محطات طاقة مضافة حالياً في ولاية ${activeWilayaObj.name} (${activeWilayaObj.code})`
              : 'لا توجد محطات أو عروض طاقة مطابقة حالياً'}
          </p>
          <p className="text-sm text-[#4A5D52]">
            يمكنك نشر فائض ألواحك الشمسية أو محطة شحن بطاريات في هذه الولاية الآن.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={onOpenPublishForWilaya}
              className="px-4 py-2 text-sm font-medium bg-[#B45309] text-white rounded-lg hover:bg-[#92400E] transition-colors"
            >
              أضف عرض طاقة في هذه الولاية
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedMode('all');
                setSearchQuery('');
                onSelectWilaya('all');
              }}
              className="px-4 py-2 text-sm font-medium bg-[#F7F9F6] text-[#0F1F16] border border-[#D7E0D5] rounded-lg hover:bg-[#ECF3ED] transition-colors"
            >
              عرض كل الولايات الـ 58
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredOffers.map((offer) => (
            <article
              key={offer.id}
              className="bg-white border border-[#E4E8E1] rounded-xl overflow-hidden flex flex-col justify-between transition-colors hover:border-[#D8CBB8]"
            >
              <div>
                <div className="aspect-[16/9] bg-[#F4F2EC] overflow-hidden">
                  <ResilientImage
                    src={offer.imageUrl}
                    alt={offer.title}
                    className="w-full h-full object-cover"
                    fallbackType="energy"
                  />
                </div>

                <div className="p-5 space-y-3">
                  {/* Unboxed Metadata */}
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#4A5D52]">
                    <span className="font-medium text-[#B45309]">
                      {offer.deliveryModeLabel}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{offer.region}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      {offer.distanceKm} كم
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>ذروة الشحن: {offer.solarPeakWindow}</span>
                  </div>

                  <h3 className="text-lg font-bold text-[#0F1F16] leading-snug">
                    {offer.title}
                  </h3>

                  <p className="text-sm text-[#4A5D52] leading-relaxed line-clamp-2">
                    {offer.description}
                  </p>

                  {/* Technical Battery & Surplus Telemetry */}
                  <div className="pt-2 border-t border-[#EFF2ED] grid grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="text-[#617569] block">الفائض المتاح</span>
                      <span className="font-semibold text-[#0F1F16] inline-flex items-center gap-1 mt-0.5 font-mono tabular-nums">
                        <Zap className="w-3.5 h-3.5 text-[#D97706]" aria-hidden="true" />
                        {offer.surplusKwh} kWh
                      </span>
                    </div>

                    <div>
                      <span className="text-[#617569] block">بطاريات جاهزة</span>
                      <span className="font-semibold text-[#0F1F16] inline-flex items-center gap-1 mt-0.5 font-mono tabular-nums">
                        <BatteryCharging
                          className="w-3.5 h-3.5 text-[#15803D]"
                          aria-hidden="true"
                        />
                        {offer.availableBatteries} × {offer.batteryUnitCapacityKwh} kWh
                      </span>
                    </div>

                    <div>
                      <span className="text-[#617569] block">جودة الخلايا والتقييم</span>
                      <span className="font-medium text-[#0F1F16] inline-flex items-center gap-1 mt-0.5 font-mono tabular-nums">
                        <Star
                          className="w-3.5 h-3.5 text-[#D97706] fill-[#D97706]"
                          aria-hidden="true"
                        />
                        {offer.rating.toFixed(1)} · {offer.batteryHealthPct}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="px-5 py-4 bg-[#FAF9F6] border-t border-[#E4E8E1] flex items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-[#617569]">
                    تعرفة الكيلوواط / تعبئة البطارية
                  </div>
                  <div className="text-lg font-bold text-[#0F1F16] font-mono tabular-nums">
                    {formatDzd(offer.pricePerKwh)}{' '}
                    <span className="text-xs font-sans font-normal text-[#4A5D52]">
                      / kWh · أو {formatDzd(offer.batteryPackPrice)} للبطارية
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOrderEnergy(offer)}
                  className="px-4 py-2 bg-[#B45309] hover:bg-[#92400E] text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
                >
                  شراء طاقة / حجز بطارية
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
