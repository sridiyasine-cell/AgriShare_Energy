import React, { useState } from 'react';
import { Check, MapPin, PlusCircle, Route } from 'lucide-react';
import { RouteLoop, RouteStop } from '../types/agrishare';

interface SmartRoutingMapProps {
  routes: RouteLoop[];
  selectedRouteId: string;
  onSelectRoute: (routeId: string) => void;
  onJoinRoute: (routeId: string, newStop: RouteStop) => void;
}

export const SmartRoutingMap: React.FC<SmartRoutingMapProps> = ({
  routes,
  selectedRouteId,
  onSelectRoute,
  onJoinRoute,
}) => {
  const activeRoute =
    routes.find((r) => r.id === selectedRouteId) ?? routes[0];

  const [farmName, setFarmName] = useState('');
  const [farmerName, setFarmerName] = useState('');
  const [taskNote, setTaskNote] = useState('حراثة أو شحن بطاريات (2 ساعة)');
  const [isOffGrid, setIsOffGrid] = useState(true);
  const [joinedNotice, setJoinedNotice] = useState<string | null>(null);

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!farmName.trim() || !farmerName.trim() || !activeRoute) return;

    // Position the newly added farm parcel near the route's existing cluster
    const lastStop = activeRoute.stops[activeRoute.stops.length - 1];
    const nextX = Math.min(560, Math.max(90, (lastStop?.x ?? 300) + 55));
    const nextY = Math.min(340, Math.max(75, (lastStop?.y ?? 200) - 35));

    const newStop: RouteStop = {
      parcelId: `p-custom-${Date.now()}`,
      parcelName: farmName.trim(),
      farmerName: farmerName.trim(),
      task: taskNote.trim() || 'خدمة ميدانية مجدولة',
      timeWindow: 'توقيت مدمج تلقائياً · 03:45 م',
      x: nextX,
      y: nextY,
      isOffGrid,
    };

    onJoinRoute(activeRoute.id, newStop);
    setJoinedNotice(
      `تمت إضافة "${farmName.trim()}" إلى ${activeRoute.name} مع خصم ${activeRoute.transportDiscountPct}% على أجور النقل.`
    );
    setFarmName('');
    setFarmerName('');
  };

  if (!activeRoute) return null;

  const polylinePoints = activeRoute.stops
    .map((stop) => `${stop.x},${stop.y}`)
    .join(' ');

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#0F1F16]">
            الجدولة الجغرافية الذكية للمعدات والبطاريات
          </h2>
          <p className="text-sm text-[#4A5D52] mt-1">
            تنظم المنصة خطوط سير المعدات بين الحقول المتقاربة آلياً لمنع الرحلات الفارغة، وتوفير أجور النقل واستهلاك المازوت.
          </p>
        </div>

        {/* Route Selector Tabs */}
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#EBF0E9] rounded-lg">
          {routes.map((route) => (
            <button
              key={route.id}
              type="button"
              onClick={() => {
                onSelectRoute(route.id);
                setJoinedNotice(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                route.id === activeRoute.id
                  ? 'bg-white text-[#15803D] shadow-xs font-semibold'
                  : 'text-[#4A5D52] hover:text-[#0F1F16]'
              }`}
            >
              {route.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Split: Interactive Rural Parcel Map + Route Schedule Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* SVG Rural Map */}
        <div className="lg:col-span-7 bg-white border border-[#E4E8E1] rounded-xl p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#4A5D52]">
            <span className="font-semibold text-[#0F1F16] inline-flex items-center gap-1.5">
              <Route className="w-4 h-4 text-[#15803D]" aria-hidden="true" />
              خريطة الحقول المتجاورة — {activeRoute.name}
            </span>
            <span className="font-mono tabular-nums">
              المسافة الموحدة: {activeRoute.optimizedDistanceKm} كم بدل{' '}
              {activeRoute.directDistanceKm} كم
            </span>
          </div>

          <div className="relative rounded-lg border border-[#E4E8E1] bg-[#F3F6F1] overflow-hidden">
            <svg
              viewBox="0 0 640 390"
              className="w-full h-auto block"
              role="img"
              aria-label={`خريطة مسار ${activeRoute.name}`}
            >
              {/* Subtle Topographic Agricultural Grid */}
              <defs>
                <pattern
                  id="agri-grid"
                  width="40"
                  height="40"
                  patternUnits="userSpaceOnUse"
                >
                  <path
                    d="M 40 0 L 0 0 0 40"
                    fill="none"
                    stroke="#DCE4D9"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="640" height="390" fill="url(#agri-grid)" />

              {/* Decorative Parcel Polygons representing rural plots */}
              <polygon
                points="60,60 260,55 245,190 70,180"
                fill="#E7EFE4"
                stroke="#CFDACC"
                strokeWidth="1.5"
              />
              <polygon
                points="280,65 550,70 535,205 270,195"
                fill="#E9F0E3"
                stroke="#CFDACC"
                strokeWidth="1.5"
              />
              <polygon
                points="85,220 320,215 310,355 75,345"
                fill="#EAECE3"
                stroke="#CFDACC"
                strokeWidth="1.5"
              />
              <polygon
                points="345,220 575,215 565,360 335,350"
                fill="#E4EDE2"
                stroke="#CFDACC"
                strokeWidth="1.5"
              />

              {/* Depot / Solar Hub Origin */}
              <g transform="translate(86, 92)">
                <rect
                  x="-14"
                  y="-14"
                  width="28"
                  height="28"
                  rx="6"
                  fill="#0F1F16"
                />
                <text
                  x="0"
                  y="4"
                  textAnchor="middle"
                  fill="#FFFFFF"
                  fontSize="11"
                  fontWeight="bold"
                >
                  مركز
                </text>
                <text
                  x="0"
                  y="28"
                  textAnchor="middle"
                  fill="#0F1F16"
                  fontSize="11"
                  fontWeight="600"
                >
                  نقطة الانطلاق
                </text>
              </g>

              {/* Dashed Unoptimized Hub-and-Spoke Lines (Visual Comparison) */}
              {activeRoute.stops.map((stop) => (
                <line
                  key={`direct-${stop.parcelId}`}
                  x1={86}
                  y1={92}
                  x2={stop.x}
                  y2={stop.y}
                  stroke="#B8C4B6"
                  strokeWidth="1.5"
                  strokeDasharray="4 5"
                />
              ))}

              {/* Optimized Continuous Loop Path */}
              <polyline
                points={`86,92 ${polylinePoints}`}
                fill="none"
                stroke="#15803D"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Route Stops */}
              {activeRoute.stops.map((stop, idx) => (
                <g key={stop.parcelId} transform={`translate(${stop.x}, ${stop.y})`}>
                  <circle
                    r="16"
                    fill={stop.isOffGrid ? '#D97706' : '#15803D'}
                    stroke="#FFFFFF"
                    strokeWidth="2.5"
                  />
                  <text
                    x="0"
                    y="4"
                    textAnchor="middle"
                    fill="#FFFFFF"
                    fontSize="12"
                    fontWeight="bold"
                  >
                    {idx + 1}
                  </text>
                  <rect
                    x="-64"
                    y="20"
                    width="128"
                    height="22"
                    rx="4"
                    fill="#FFFFFF"
                    stroke="#D7E0D5"
                    strokeWidth="1"
                  />
                  <text
                    x="0"
                    y="35"
                    textAnchor="middle"
                    fill="#0F1F16"
                    fontSize="10.5"
                    fontWeight="600"
                  >
                    {stop.parcelName.slice(0, 22)}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          {/* Map Legend + Fuel Savings Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-1 text-xs text-[#4A5D52]">
            <div className="flex flex-wrap items-center gap-4">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-[#15803D] inline-block" />
                مسار مجدول متسلسل
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-0.5 border-t border-dashed border-[#9CA89A] inline-block" />
                تنقل فردي غير مجدول
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#D97706] inline-block" />
                مزرعة معزولة خارج الشبكة
              </span>
            </div>

            <div className="font-mono tabular-nums font-semibold text-[#15803D]">
              توفير {activeRoute.dieselSavedLiters} لتر مازوت · خصم نقل{' '}
              {activeRoute.transportDiscountPct}%
            </div>
          </div>
        </div>

        {/* Right Side: Route Schedule Queue & Join Form */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white border border-[#E4E8E1] rounded-xl p-5 space-y-4">
            <div className="border-b border-[#EFF2ED] pb-3">
              <div className="text-xs text-[#4A5D52]">
                {activeRoute.dateLabel} · {activeRoute.operatorName}
              </div>
              <h3 className="text-lg font-bold text-[#0F1F16] mt-1">
                {activeRoute.equipmentName}
              </h3>
            </div>

            <ol className="space-y-3">
              {activeRoute.stops.map((stop, idx) => (
                <li
                  key={stop.parcelId}
                  className="flex items-start gap-3 pb-3 border-b border-[#F2F5F0] last:border-b-0 last:pb-0"
                >
                  <span
                    className={`w-6 h-6 rounded-md text-xs font-mono font-bold flex items-center justify-center shrink-0 mt-0.5 text-white ${
                      stop.isOffGrid ? 'bg-[#D97706]' : 'bg-[#15803D]'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold text-[#0F1F16] truncate">
                        {stop.parcelName}
                      </span>
                      <span className="text-xs font-mono tabular-nums text-[#617569] shrink-0">
                        {stop.timeWindow}
                      </span>
                    </div>
                    <div className="text-xs text-[#4A5D52] mt-0.5">
                      {stop.farmerName} · {stop.task}
                      {stop.isOffGrid ? ' · حقل معزول عن الشبكة' : ''}
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          {/* Join Route Form */}
          <form
            onSubmit={handleJoinSubmit}
            className="bg-white border border-[#E4E8E1] rounded-xl p-5 space-y-4"
          >
            <div className="flex items-center gap-2 text-sm font-bold text-[#0F1F16]">
              <MapPin className="w-4 h-4 text-[#15803D]" aria-hidden="true" />
              <span>ضم حقلك لهذا المسار الذكي</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="join-farm-name"
                  className="block text-xs font-medium text-[#4A5D52] mb-1"
                >
                  اسم الحقل أو القطعة
                </label>
                <input
                  id="join-farm-name"
                  type="text"
                  required
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  placeholder="مثال: مزرعة الريحان - قطعة 9"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                />
              </div>

              <div>
                <label
                  htmlFor="join-farmer-name"
                  className="block text-xs font-medium text-[#4A5D52] mb-1"
                >
                  اسم المزارع
                </label>
                <input
                  id="join-farmer-name"
                  type="text"
                  required
                  value={farmerName}
                  onChange={(e) => setFarmerName(e.target.value)}
                  placeholder="مثال: خالد الدوسري"
                  className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="join-task-note"
                className="block text-xs font-medium text-[#4A5D52] mb-1"
              >
                المهمة المطلوبة
              </label>
              <input
                id="join-task-note"
                type="text"
                value={taskNote}
                onChange={(e) => setTaskNote(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-[#F7F9F6] border border-[#E4E8E1] rounded-lg focus:outline-none focus:border-[#15803D]"
              />
            </div>

            <label className="flex items-center gap-2 text-xs text-[#4A5D52] cursor-pointer">
              <input
                type="checkbox"
                checked={isOffGrid}
                onChange={(e) => setIsOffGrid(e.target.checked)}
                className="rounded border-[#C5D1C3] text-[#15803D] focus:ring-[#15803D]"
              />
              <span>حقل معزول غير مربوط بالشبكة الكهربائية</span>
            </label>

            {joinedNotice && (
              <div className="p-3 rounded-lg bg-[#EEF5EE] border border-[#CDE0CD] text-xs text-[#166534] flex items-start gap-2">
                <Check className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{joinedNotice}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#15803D] hover:bg-[#166534] text-white text-sm font-medium rounded-lg transition-colors min-h-[42px]"
            >
              <PlusCircle className="w-4 h-4" aria-hidden="true" />
              <span>إدراج الحقـل في المسار وتوفير {activeRoute.transportDiscountPct}% نقل</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
