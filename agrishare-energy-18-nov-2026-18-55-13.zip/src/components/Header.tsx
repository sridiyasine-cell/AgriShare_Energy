import React, { useState } from 'react';
import { Menu, Plus, X } from 'lucide-react';
import { PlatformView } from '../types/agrishare';

interface HeaderProps {
  activeView: PlatformView;
  onSelectView: (view: PlatformView) => void;
  onOpenPublishModal: () => void;
}

const NAV_ITEMS: { id: PlatformView; label: string }[] = [
  { id: 'equipment', label: 'سوق المعدات' },
  { id: 'energy', label: 'سوق الطاقة' },
  { id: 'routing', label: 'الجدولة الجغرافية' },
  { id: 'requests', label: 'تسجيل وطلبات' },
  { id: 'trust', label: 'السجلات والثقة' },
];

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onSelectView,
  onOpenPublishModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (view: PlatformView) => {
    onSelectView(view);
    setMobileMenuOpen(false);
    const workspaceEl = document.getElementById('workspace-section');
    if (workspaceEl) {
      workspaceEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#F7F9F6]/95 backdrop-blur-sm border-b border-[#E4E8E1]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand mark + wordmark */}
        <button
          type="button"
          onClick={() => handleNavClick('equipment')}
          className="inline-flex items-center gap-2.5 text-lg font-bold tracking-tight text-[#0F1F16] whitespace-nowrap shrink-0 font-display focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#15803D] rounded-md px-1"
        >
          <span className="w-10 h-10 rounded-full overflow-hidden shrink-0 flex items-center justify-center bg-transparent">
            <img
              src="/assets/aistudio/2b7084da-ef95-417d-b423-1e1d05e64c21_193bf8b4.jpg"
              alt="شعار AgriShare Energy"
              className="w-full h-full object-cover origin-[50%_38%] scale-[1.85] mix-blend-multiply"
            />
          </span>
          <span>AgriShare Energy</span>
        </button>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="التنقل الرئيسي"
          className="hidden md:flex items-center gap-6 text-sm font-medium text-[#4A5D52]"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                className={`relative py-1 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#15803D] rounded-sm ${
                  isActive
                    ? 'text-[#0F1F16] font-semibold'
                    : 'hover:text-[#0F1F16]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[21px] h-[2px] bg-[#15803D]"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenPublishModal}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#15803D] hover:bg-[#166534] rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#15803D]"
          >
            <Plus className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>أضف عرضاً</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label={mobileMenuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            aria-expanded={mobileMenuOpen}
            className="md:hidden p-2 text-[#0F1F16] hover:bg-[#E9EFE7] rounded-lg transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="قائمة الجوال"
          className="md:hidden border-t border-[#E4E8E1] bg-white px-4 py-3 flex flex-col gap-1"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium transition-colors min-h-[44px] ${
                  isActive
                    ? 'bg-[#EEF5EE] text-[#15803D] font-semibold'
                    : 'text-[#4A5D52] hover:bg-[#F7F9F6] hover:text-[#0F1F16]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
      )}
    </header>
  );
};
