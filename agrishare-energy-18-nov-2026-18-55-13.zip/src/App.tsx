import { useMemo, useState } from 'react';
import {
  INITIAL_DIGITAL_LOGS,
  INITIAL_ENERGY_OFFERS,
  INITIAL_EQUIPMENT,
  INITIAL_NEED_REQUESTS,
  INITIAL_REVIEWS,
  INITIAL_ROUTES,
  MAINTENANCE_PROVIDERS,
} from './data/seedData';
import {
  BookingRecord,
  DigitalLogEntry,
  EnergyOffer,
  EquipmentItem,
  FarmerProfile,
  FarmerReview,
  NeedRequest,
  PlatformView,
  RouteLoop,
  RouteStop,
} from './types/agrishare';
import { Header } from './components/Header';
import { HeroOverview } from './components/HeroOverview';
import { EquipmentMarketplace } from './components/EquipmentMarketplace';
import { EnergyMarketplace } from './components/EnergyMarketplace';
import { SmartRoutingMap } from './components/SmartRoutingMap';
import { FarmerRequestsView } from './components/FarmerRequestsView';
import { TrustAndLogsView } from './components/TrustAndLogsView';
import { BusinessModelView } from './components/BusinessModelView';
import { BookingModal, BookingTarget } from './components/BookingModal';
import { PublishOfferModal } from './components/PublishOfferModal';

const INITIAL_BOOKINGS: BookingRecord[] = [
  {
    id: 'DZ-8841',
    kind: 'equipment',
    itemTitle: 'جرار زراعي رباعي الدفع — John Deere 6155M',
    providerName: 'عمي لخضر بن عيسى',
    quantityLabel: '3 ساعات',
    baseAmount: 11220,
    routeDiscount: 480,
    microInsuranceFee: 450,
    platformCommission: 673,
    totalPaid: 12343,
    deliveryNote: 'مدمج مع مسار سهل متيجة الشرقي · ولاية البليدة (09)',
    createdAt: '2026-11-16',
  },
  {
    id: 'DZ-3902',
    kind: 'energy',
    itemTitle: 'محطة شحن بطاريات الليثيوم — مزرعة الرمال الذهبية',
    providerName: 'كريم بلقاسم',
    quantityLabel: '2 بطارية (10 kWh)',
    baseAmount: 440,
    routeDiscount: 0,
    microInsuranceFee: 450,
    platformCommission: 26,
    totalPaid: 916,
    deliveryNote: 'تعبئة واستلام بطارية · ولاية الوادي (39)',
    createdAt: '2026-11-17',
  },
];

export default function App() {
  const [activeView, setActiveView] = useState<PlatformView>('equipment');
  const [selectedWilaya, setSelectedWilaya] = useState<string>('all');
  const [equipmentList, setEquipmentList] =
    useState<EquipmentItem[]>(INITIAL_EQUIPMENT);
  const [energyOffers, setEnergyOffers] =
    useState<EnergyOffer[]>(INITIAL_ENERGY_OFFERS);
  const [routes, setRoutes] = useState<RouteLoop[]>(INITIAL_ROUTES);
  const [selectedRouteId, setSelectedRouteId] = useState<string>(
    INITIAL_ROUTES[0].id
  );
  const [digitalLogs, setDigitalLogs] =
    useState<DigitalLogEntry[]>(INITIAL_DIGITAL_LOGS);
  const [reviews, setReviews] = useState<FarmerReview[]>(INITIAL_REVIEWS);
  const [bookings, setBookings] = useState<BookingRecord[]>(INITIAL_BOOKINGS);
  const [registeredProfile, setRegisteredProfile] =
    useState<FarmerProfile | null>(null);
  const [needRequests, setNeedRequests] = useState<NeedRequest[]>(
    INITIAL_NEED_REQUESTS
  );

  const [bookingTarget, setBookingTarget] = useState<BookingTarget | null>(null);
  const [isPublishOpen, setIsPublishOpen] = useState(false);

  const totalSurplusKwh = useMemo(
    () => energyOffers.reduce((sum, item) => sum + item.surplusKwh, 0),
    [energyOffers]
  );

  const totalDieselSavedLiters = useMemo(
    () => routes.reduce((sum, r) => sum + r.dieselSavedLiters, 0),
    [routes]
  );

  const handleInspectRoute = (routeId: string) => {
    setSelectedRouteId(routeId);
    setActiveView('routing');
    const el = document.getElementById('workspace-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleJoinRoute = (routeId: string, newStop: RouteStop) => {
    setRoutes((prev) =>
      prev.map((route) => {
        if (route.id !== routeId) return route;
        return {
          ...route,
          directDistanceKm: route.directDistanceKm + 14,
          optimizedDistanceKm: route.optimizedDistanceKm + 4,
          dieselSavedLiters: route.dieselSavedLiters + 9,
          stops: [...route.stops, newStop],
        };
      })
    );
  };

  const handleConfirmBooking = (
    record: Omit<BookingRecord, 'id' | 'createdAt'>
  ) => {
    const newRecord: BookingRecord = {
      ...record,
      id: `DZ-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: '2026-11-18',
    };
    setBookings((prev) => [newRecord, ...prev]);
  };

  const handleAddReview = (
    review: Omit<FarmerReview, 'id' | 'dateLabel' | 'verifiedBookingCode'>
  ) => {
    const newReview: FarmerReview = {
      ...review,
      id: `rev-${Date.now()}`,
      dateLabel: '2026-11-18',
      verifiedBookingCode: bookings[0]?.id ?? 'AG-9120',
    };
    setReviews((prev) => [newReview, ...prev]);
  };

  const handlePublishEquipment = (item: EquipmentItem) => {
    setEquipmentList((prev) => [item, ...prev]);
    setDigitalLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        assetCode: `EQ-${Math.floor(100 + Math.random() * 899)}`,
        assetName: item.name,
        assetType: 'معدة زراعية',
        ownerName: item.ownerName,
        metricLabel: 'ساعات التشغيل / الفحص',
        metricValue: `${item.operatingHours} ساعة · فحص التسجيل الأولي 100%`,
        lastCheckDate: item.lastInspectionDate,
        conditionStatus: 'موثوق ومفحوص',
      },
      ...prev,
    ]);
    setActiveView('equipment');
  };

  const handlePublishEnergy = (offer: EnergyOffer) => {
    setEnergyOffers((prev) => [offer, ...prev]);
    setDigitalLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        assetCode: `EN-${Math.floor(100 + Math.random() * 899)}`,
        assetName: offer.title,
        assetType: 'محطة طاقة وبطاريات',
        ownerName: offer.providerName,
        metricLabel: 'صحة الخلايا / الدورات',
        metricValue: `${offer.batteryHealthPct}% صحة · ${offer.chargeCycles} دورة شحن`,
        lastCheckDate: '2026-11-18',
        conditionStatus: 'موثوق ومفحوص',
      },
      ...prev,
    ]);
    setActiveView('energy');
  };

  const handleRegisterProfile = (profile: FarmerProfile) => {
    setRegisteredProfile(profile);
    setSelectedWilaya(profile.wilayaCode);
  };

  const handleSubmitNeedRequest = (
    req: Omit<NeedRequest, 'id' | 'status' | 'createdAt'>
  ) => {
    const newReq: NeedRequest = {
      ...req,
      id: `REQ-${Math.floor(504 + Math.random() * 490)}`,
      status: 'طلب مفتوح',
      createdAt: '2026-11-18',
    };
    setNeedRequests((prev) => [newReq, ...prev]);
  };

  const handleFulfillRequest = (requestId: string, providerName: string) => {
    setNeedRequests((prev) =>
      prev.map((req) =>
        req.id === requestId
          ? { ...req, status: 'تمت مطابقة مزود', matchedProvider: providerName }
          : req
      )
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F9F6] text-[#0F1F16]">
      <Header
        activeView={activeView}
        onSelectView={setActiveView}
        onOpenPublishModal={() => setIsPublishOpen(true)}
      />

      <main className="flex-1">
        <HeroOverview
          equipmentCount={equipmentList.length}
          totalSurplusKwh={totalSurplusKwh}
          totalDieselSavedLiters={totalDieselSavedLiters}
          bookingsCount={bookings.length}
          onNavigateView={setActiveView}
        />

        {/* Workspace Navigation Tabs + Active Module */}
        <section
          id="workspace-section"
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6"
        >
          {/* Quick View Switcher Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E4E8E1] pb-4">
            <div
              className="flex flex-wrap items-center gap-1 p-1 bg-[#EBF0E9] rounded-lg"
              role="tablist"
              aria-label="أقسام منصة AgriShare Energy"
            >
              {(
                [
                  { id: 'equipment', label: 'مشاركة المعدات' },
                  { id: 'energy', label: 'سوق الطاقة والبطاريات' },
                  { id: 'routing', label: 'الجدولة الجغرافية' },
                  { id: 'requests', label: 'تسجيل وطلب احتياج' },
                  { id: 'trust', label: 'السجلات والثقة' },
                  { id: 'business', label: 'نموذج الأعمال' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={activeView === tab.id}
                  type="button"
                  onClick={() => setActiveView(tab.id)}
                  className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    activeView === tab.id
                      ? 'bg-white text-[#0F1F16] shadow-xs font-semibold'
                      : 'text-[#4A5D52] hover:text-[#0F1F16]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="text-xs text-[#4A5D52]">
              شبكة تعاونية فلاحية عبر 58 ولاية · الدفع بالدينار الجزائري (د.ج) · عمولة 6%
            </div>
          </div>

          {activeView === 'equipment' && (
            <EquipmentMarketplace
              items={equipmentList}
              selectedWilaya={selectedWilaya}
              onSelectWilaya={setSelectedWilaya}
              onBookEquipment={(item, preferredUnit) =>
                setBookingTarget({ type: 'equipment', item, preferredUnit })
              }
              onInspectRoute={handleInspectRoute}
              onOpenPublishForWilaya={() => setIsPublishOpen(true)}
            />
          )}

          {activeView === 'energy' && (
            <EnergyMarketplace
              offers={energyOffers}
              selectedWilaya={selectedWilaya}
              onSelectWilaya={setSelectedWilaya}
              onOrderEnergy={(offer) =>
                setBookingTarget({ type: 'energy', offer })
              }
              onOpenPublishForWilaya={() => setIsPublishOpen(true)}
            />
          )}

          {activeView === 'routing' && (
            <SmartRoutingMap
              routes={routes}
              selectedRouteId={selectedRouteId}
              onSelectRoute={setSelectedRouteId}
              onJoinRoute={handleJoinRoute}
            />
          )}

          {activeView === 'requests' && (
            <FarmerRequestsView
              profile={registeredProfile}
              requests={needRequests}
              selectedWilaya={selectedWilaya}
              onSelectWilaya={setSelectedWilaya}
              onRegisterProfile={handleRegisterProfile}
              onResetProfile={() => setRegisteredProfile(null)}
              onSubmitRequest={handleSubmitNeedRequest}
              onFulfillRequest={handleFulfillRequest}
            />
          )}

          {activeView === 'trust' && (
            <TrustAndLogsView
              logs={digitalLogs}
              reviews={reviews}
              maintenanceProviders={MAINTENANCE_PROVIDERS}
              onAddReview={handleAddReview}
              onBookMaintenance={(provider) =>
                setBookingTarget({ type: 'maintenance', provider })
              }
            />
          )}

          {activeView === 'business' && <BusinessModelView bookings={bookings} />}
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-[#E4E8E1] bg-white mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#4A5D52]">
          <div className="flex items-center gap-3 font-semibold text-[#0F1F16]">
            <img
              src="/assets/aistudio/2b7084da-ef95-417d-b423-1e1d05e64c21_193bf8b4.jpg"
              alt="شعار AgriShare Energy"
              className="h-12 w-auto object-contain mix-blend-multiply shrink-0"
            />
            <span>
              AgriShare Energy الجزائر — شبكة مشاركة المعدات الفلاحية والطاقة الشمسية عبر 58 ولاية (د.ج)
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => setActiveView('equipment')}
              className="hover:text-[#0F1F16]"
            >
              سوق المعدات
            </button>
            <button
              type="button"
              onClick={() => setActiveView('energy')}
              className="hover:text-[#0F1F16]"
            >
              سوق الطاقة
            </button>
            <button
              type="button"
              onClick={() => setActiveView('routing')}
              className="hover:text-[#0F1F16]"
            >
              الجدولة الجغرافية
            </button>
            <button
              type="button"
              onClick={() => setActiveView('requests')}
              className="hover:text-[#0F1F16]"
            >
              تسجيل وطلب احتياج
            </button>
            <button
              type="button"
              onClick={() => setActiveView('trust')}
              className="hover:text-[#0F1F16]"
            >
              الثقة والسجلات
            </button>
            <button
              type="button"
              onClick={() => setActiveView('business')}
              className="hover:text-[#0F1F16]"
            >
              نموذج الأعمال
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <BookingModal
        key={
          bookingTarget
            ? bookingTarget.type === 'equipment'
              ? `eq-${bookingTarget.item.id}`
              : bookingTarget.type === 'energy'
              ? `en-${bookingTarget.offer.id}`
              : `mp-${bookingTarget.provider.id}`
            : 'closed'
        }
        target={bookingTarget}
        onClose={() => setBookingTarget(null)}
        onConfirmBooking={handleConfirmBooking}
      />

      {isPublishOpen && (
        <PublishOfferModal
          isOpen={isPublishOpen}
          defaultWilayaCode={selectedWilaya}
          onClose={() => setIsPublishOpen(false)}
          onPublishEquipment={handlePublishEquipment}
          onPublishEnergy={handlePublishEnergy}
        />
      )}
    </div>
  );
}
