export type PlatformView =
  | 'equipment'
  | 'energy'
  | 'routing'
  | 'requests'
  | 'trust'
  | 'business';

export type EquipmentCategory =
  | 'all'
  | 'tractor'
  | 'harvester'
  | 'irrigation'
  | 'seeder';

export type PricingUnit = 'hour' | 'hectare';

export interface EquipmentItem {
  id: string;
  name: string;
  category: Exclude<EquipmentCategory, 'all'>;
  categoryLabel: string;
  ownerName: string;
  wilayaCode: string;
  wilayaName: string;
  ownerRegion: string;
  distanceKm: number;
  pricePerHour: number;
  pricePerHectare: number;
  horsepower: string;
  rating: number;
  reviewsCount: number;
  operatingHours: number;
  lastInspectionDate: string;
  technicalStatus: 'جاهز للعمل' | 'قيد المعايرة' | 'في مسار مجدول';
  nearestRouteId: string;
  nearestRouteName: string;
  imageUrl: string;
  description: string;
  fuelEfficiencyNote: string;
}

export type EnergyDeliveryMode =
  | 'all'
  | 'battery_pickup'
  | 'battery_delivery'
  | 'direct_grid';

export interface EnergyOffer {
  id: string;
  title: string;
  providerName: string;
  wilayaCode: string;
  wilayaName: string;
  region: string;
  distanceKm: number;
  deliveryMode: Exclude<EnergyDeliveryMode, 'all'>;
  deliveryModeLabel: string;
  surplusKwh: number;
  availableBatteries: number;
  batteryUnitCapacityKwh: number;
  pricePerKwh: number;
  batteryPackPrice: number;
  batteryHealthPct: number;
  chargeCycles: number;
  rating: number;
  reviewsCount: number;
  solarPeakWindow: string;
  imageUrl: string;
  description: string;
}

export interface RouteStop {
  parcelId: string;
  parcelName: string;
  farmerName: string;
  task: string;
  timeWindow: string;
  x: number;
  y: number;
  isOffGrid: boolean;
}

export interface RouteLoop {
  id: string;
  name: string;
  wilayaLabel: string;
  equipmentName: string;
  operatorName: string;
  dateLabel: string;
  directDistanceKm: number;
  optimizedDistanceKm: number;
  dieselSavedLiters: number;
  transportDiscountPct: number;
  stops: RouteStop[];
}

export interface DigitalLogEntry {
  id: string;
  assetCode: string;
  assetName: string;
  assetType: 'معدة زراعية' | 'محطة طاقة وبطاريات';
  ownerName: string;
  metricLabel: string;
  metricValue: string;
  lastCheckDate: string;
  conditionStatus: 'موثوق ومفحوص' | 'يحتاج صيانة دورية';
}

export interface FarmerReview {
  id: string;
  authorName: string;
  authorFarm: string;
  targetName: string;
  targetType: 'معدة' | 'طاقة وبطاريات';
  rating: number;
  comment: string;
  dateLabel: string;
  verifiedBookingCode: string;
}

export interface MaintenanceProvider {
  id: string;
  name: string;
  specialty: 'صيانة الجرارات والحصادات' | 'أنظمة الطاقة الشمسية والبطاريات' | 'مضخات الري والكهرباء الريفية';
  wilayaCode: string;
  region: string;
  responseTime: string;
  baseFee: number;
  rating: number;
  completedJobs: number;
}

export interface BookingRecord {
  id: string;
  kind: 'equipment' | 'energy' | 'maintenance';
  itemTitle: string;
  providerName: string;
  quantityLabel: string;
  baseAmount: number;
  routeDiscount: number;
  microInsuranceFee: number;
  platformCommission: number;
  totalPaid: number;
  deliveryNote: string;
  createdAt: string;
}

export interface FarmerProfile {
  memberCode: string;
  fullName: string;
  roleType: 'مزارع صغير' | 'مواطن / مستثمرة عائلية' | 'تعاونية فلاحية';
  phone: string;
  wilayaCode: string;
  wilayaName: string;
  municipality: string;
  gridStatus: 'مربوط بالشبكة الكهربائية' | 'معزول / خارج الشبكة';
  farmAreaHectares: string;
  registeredAt: string;
}

export type NeedCategory =
  | 'equipment_rental'
  | 'energy_battery'
  | 'solar_irrigation'
  | 'maintenance_install';

export interface NeedRequest {
  id: string;
  requesterName: string;
  requesterRole: string;
  requesterPhone: string;
  wilayaCode: string;
  wilayaName: string;
  municipality: string;
  isOffGrid: boolean;
  category: NeedCategory;
  categoryLabel: string;
  title: string;
  quantityNeeded: string;
  neededDate: string;
  maxBudgetDzd: number;
  notes: string;
  status: 'طلب مفتوح' | 'تمت مطابقة مزود';
  matchedProvider?: string;
  createdAt: string;
}

